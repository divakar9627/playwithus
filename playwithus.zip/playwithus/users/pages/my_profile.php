<?php
session_start();
include '../../includes/config.php'; // ✅ CORRECT PATH

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php'); // ✅ CORRECT PATH
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Fetch user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        header('Location: ../../logout.php'); // ✅ CORRECT PATH
        exit();
    }
} catch(PDOException $e) {
    $errors[] = 'Database error: ' . $e->getMessage();
}

// Handle profile update with game IDs
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pubg_id = trim($_POST['pubg_id'] ?? '');
    $freefire_id = trim($_POST['freefire_id'] ?? '');
    
    try {
        // Update database
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, pubg_id = ?, freefire_id = ? WHERE id = ?");
        $stmt->execute([$full_name, $phone, $pubg_id, $freefire_id, $user_id]);
        
        // Update user folder files
        updateUserGameIDs($user_id, $pubg_id, $freefire_id, $full_name, $phone);
        
        $_SESSION['success'] = 'Profile updated successfully!';
        header('Location: my_profile.php');
        exit();
        
    } catch(PDOException $e) {
        $errors[] = 'Failed to update profile: ' . $e->getMessage();
    }
}

// Update game IDs in user folder
function updateUserGameIDs($user_id, $pubg_id, $freefire_id, $full_name, $phone) {
    $user_folder = "../../users/" . $user_id; // ✅ CORRECT PATH
    
    if (is_dir($user_folder)) {
        // Update game ID files
        file_put_contents($user_folder . '/game_ids/pubg_id.txt', $pubg_id);
        file_put_contents($user_folder . '/game_ids/freefire_id.txt', $freefire_id);
        
        // Update profile info
        $profile_file = $user_folder . '/profile/info.json';
        if (file_exists($profile_file)) {
            $profile_data = json_decode(file_get_contents($profile_file), true);
            $profile_data['pubg_id'] = $pubg_id;
            $profile_data['freefire_id'] = $freefire_id;
            $profile_data['full_name'] = $full_name;
            $profile_data['phone'] = $phone;
            file_put_contents($profile_file, json_encode($profile_data, JSON_PRETTY_PRINT));
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Simple Navigation (Temporary) -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">
                <a href="../../index.php">PlayWithUs</a>
            </div>
            <div class="flex space-x-4">
                <a href="../../index.php" class="text-yellow-400 hover:text-yellow-300">Home</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-300">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Profile Section -->
    <section class="py-12 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto">
                <!-- Header -->
                <div class="text-center mb-12">
                    <h1 class="text-4xl font-bold text-yellow-400 mb-4">My Profile</h1>
                    <p class="text-gray-400 text-lg">Welcome back, <?= htmlspecialchars($user['username']) ?>!</p>
                </div>

                <!-- Success/Error Messages -->
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="bg-green-600 text-white p-4 rounded-lg mb-6 text-center">
                        <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="bg-red-600 text-white p-4 rounded-lg mb-6">
                        <?php foreach($errors as $error): ?>
                            <p><?= $error ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="bg-gray-800 rounded-xl p-8 shadow-lg">
                    <h3 class="text-2xl font-bold text-yellow-400 mb-6">Edit Your Profile</h3>
                    
                    <form method="POST">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            <!-- Basic Info -->
                            <div class="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-gray-300 mb-2">Username</label>
                                    <input type="text" value="<?= htmlspecialchars($user['username']) ?>" 
                                           class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-400" disabled>
                                </div>
                                
                                <div>
                                    <label class="block text-gray-300 mb-2">Email</label>
                                    <input type="email" value="<?= htmlspecialchars($user['email']) ?>" 
                                           class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-400" disabled>
                                </div>
                            </div>

                            <div>
                                <label for="full_name" class="block text-gray-300 mb-2">Full Name</label>
                                <input type="text" id="full_name" name="full_name" 
                                       value="<?= htmlspecialchars($user['full_name'] ?? '') ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-yellow-500 text-white"
                                       placeholder="Enter your full name">
                            </div>
                            
                            <div>
                                <label for="phone" class="block text-gray-300 mb-2">Phone Number</label>
                                <input type="tel" id="phone" name="phone" 
                                       value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-yellow-500 text-white"
                                       placeholder="+91 1234567890">
                            </div>

                            <!-- Gaming IDs -->
                            <div class="md:col-span-2">
                                <h4 class="text-lg font-semibold text-yellow-400 mb-4 border-b border-gray-700 pb-2">
                                    <i class="fas fa-gamepad mr-2"></i>Gaming IDs
                                </h4>
                            </div>
                            
                            <div>
                                <label for="pubg_id" class="block text-gray-300 mb-2">
                                    <i class="fab fa-battle-net mr-2 text-blue-400"></i>PUBG ID
                                </label>
                                <input type="text" id="pubg_id" name="pubg_id" 
                                       value="<?= htmlspecialchars($user['pubg_id'] ?? '') ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-yellow-500 text-white"
                                       placeholder="Your PUBG Player ID">
                            </div>
                            
                            <div>
                                <label for="freefire_id" class="block text-gray-300 mb-2">
                                    <i class="fas fa-fire mr-2 text-orange-400"></i>Free Fire ID
                                </label>
                                <input type="text" id="freefire_id" name="freefire_id" 
                                       value="<?= htmlspecialchars($user['freefire_id'] ?? '') ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-yellow-500 text-white"
                                       placeholder="Your Free Fire Player ID">
                            </div>
                        </div>

                        <div class="mt-8">
                            <button type="submit" 
                                    class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-6 rounded-xl transition duration-300 text-lg">
                                <i class="fas fa-save mr-2"></i>Update Profile
                            </button>
                        </div>
                    </form>
                </div>

                <!-- User Folder Info -->
                <div class="mt-8 bg-gray-800 rounded-xl p-6">
                    <h4 class="text-lg font-semibold text-yellow-400 mb-4">Your Data Storage</h4>
                    <p class="text-gray-400">Your profile data is stored in: <code class="text-yellow-400">users/<?= $user_id ?>/</code></p>
                    <p class="text-gray-400 text-sm mt-2">Game IDs, tournament history, and wallet data are automatically saved.</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>