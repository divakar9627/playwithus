<?php
session_start();
include '../../includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Initialize variables
$current_balance = 0.00;
$transactions = [];

// Check database connection
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch user's current balance
$balance_query = "SELECT balance FROM users WHERE id = ?";
if ($stmt = $conn->prepare($balance_query)) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user_data = $result->fetch_assoc();
            $current_balance = $user_data['balance'] ?? 0.00;
        }
    }
    $stmt->close();
}

// Fetch recent transactions
$transactions_query = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
if ($stmt = $conn->prepare($transactions_query)) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $transactions_result = $stmt->get_result();
        while ($row = $transactions_result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    $stmt->close();
}

// Handle deposit request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deposit'])) {
    $amount = floatval($_POST['amount']);
    $payment_method = $_POST['payment_method'] ?? 'upi';
    
    if ($amount > 0 && $amount <= 100000) {
        $transaction_type = 'deposit';
        $status = 'pending';
        
        $insert_query = "INSERT INTO transactions (user_id, type, amount, status, payment_method) VALUES (?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($insert_query)) {
            $stmt->bind_param("isdss", $user_id, $transaction_type, $amount, $status, $payment_method);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Deposit request of ₹" . number_format($amount, 2) . " submitted successfully!";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error processing deposit request.";
                $_SESSION['message_type'] = "error";
            }
            $stmt->close();
        }
    } else {
        $_SESSION['message'] = "Invalid deposit amount. Please enter an amount between ₹1 and ₹1,00,000.";
        $_SESSION['message_type'] = "error";
    }
    header("Location: my_wallet.php");
    exit();
}

// Handle withdrawal request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw'])) {
    $amount = floatval($_POST['amount']);
    $withdrawal_method = $_POST['withdrawal_method'] ?? 'bank';
    
    if ($amount > 0 && $amount <= $current_balance) {
        // Start transaction for data consistency
        $conn->begin_transaction();
        
        try {
            // Insert withdrawal transaction
            $transaction_type = 'withdrawal';
            $status = 'pending';
            
            $insert_query = "INSERT INTO transactions (user_id, type, amount, status, payment_method) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("isdss", $user_id, $transaction_type, $amount, $status, $withdrawal_method);
            $stmt->execute();
            $stmt->close();
            
            // Update user balance
            $update_query = "UPDATE users SET balance = balance - ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("di", $amount, $user_id);
            $stmt->execute();
            $stmt->close();
            
            $conn->commit();
            
            $_SESSION['message'] = "Withdrawal request of ₹" . number_format($amount, 2) . " submitted successfully!";
            $_SESSION['message_type'] = "success";
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "Error processing withdrawal request.";
            $_SESSION['message_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "Invalid withdrawal amount or insufficient balance.";
        $_SESSION['message_type'] = "error";
    }
    header("Location: my_wallet.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wallet - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .pulse-warning {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body class="bg-gray-900 text-white font-sans">
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">
                <a href="../../index.php">PlayWithUs</a>
            </div>
            <div class="flex space-x-4">
                <a href="my_profile.php" class="text-yellow-400 hover:text-yellow-300">My Profile</a>
                <a href="../../index.php" class="text-yellow-400 hover:text-yellow-300">Home</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-300">Logout</a>
            </div>
        </div>
    </nav>

    <section class="py-12 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <!-- Success/Error Messages -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="max-w-4xl mx-auto mb-6 p-4 rounded-lg fade-in <?php echo $_SESSION['message_type'] === 'success' ? 'bg-green-800 text-green-100' : 'bg-red-800 text-red-100'; ?>">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <?php if ($_SESSION['message_type'] === 'success'): ?>
                                <i class="fas fa-check-circle mr-2"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-circle mr-2"></i>
                            <?php endif; ?>
                            <?php 
                            echo $_SESSION['message']; 
                            unset($_SESSION['message']);
                            unset($_SESSION['message_type']);
                            ?>
                        </div>
                        <button onclick="this.parentElement.parentElement.remove()" class="text-lg">&times;</button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h1 class="text-4xl font-bold text-yellow-400 mb-4">My Wallet</h1>
                    <p class="text-gray-400 text-lg">Manage your balance and transactions</p>
                </div>

                <!-- Balance Card -->
                <div class="bg-gray-800 rounded-xl p-8 shadow-lg mb-8 fade-in">
                    <div class="text-center mb-8">
                        <div class="bg-yellow-500 text-black rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 pulse-warning">
                            <i class="fas fa-wallet text-3xl"></i>
                        </div>
                        <h2 class="text-3xl font-bold text-white">₹<?php echo number_format($current_balance, 2); ?></h2>
                        <p class="text-gray-400">Current Balance</p>



                        <!-- Balance Card ke andar action buttons -->
<div class="flex flex-col md:flex-row justify-center gap-4 mb-8">
    <button 
        onclick="window.location.href='../../payment/?amount=500'"
        class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition transform hover:scale-105"
    >
        <i class="fas fa-plus-circle"></i> Add Money
    </button>
    <button 
        id="withdrawBtn" 
        class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition transform hover:scale-105"
        <?php echo $current_balance <= 0 ? 'disabled' : ''; ?>
    >
        <i class="fas fa-minus-circle"></i> Withdraw Money
    </button>
</div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex flex-col md:flex-row justify-center gap-4 mb-8">
                        <button 
                            id="depositBtn" 
                            class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition transform hover:scale-105"
                        >
                            <i class="fas fa-plus-circle"></i> Deposit Money
                        </button>
                        <button 
                            id="withdrawBtn" 
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition transform hover:scale-105"
                            <?php echo $current_balance <= 0 ? 'disabled' : ''; ?>
                        >
                            <i class="fas fa-minus-circle"></i> Withdraw Money
                        </button>
                    </div>
                </div>

                <!-- Deposit Modal -->
                <div id="depositModal" class="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 hidden fade-in">
                    <div class="bg-gray-800 rounded-xl p-6 w-full max-w-md mx-4">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-yellow-400">Deposit Money</h3>
                            <button id="closeDepositModal" class="text-gray-400 hover:text-white text-xl">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <form method="POST" action="my_wallet.php" id="depositForm">
                            <div class="mb-4">
                                <label class="block text-gray-400 mb-2">Amount (₹)</label>
                                <input 
                                    type="number" 
                                    name="amount" 
                                    min="1" 
                                    max="100000"
                                    step="0.01" 
                                    class="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500" 
                                    placeholder="Enter amount"
                                    required
                                >
                                <p class="text-gray-500 text-sm mt-1">Minimum: ₹1, Maximum: ₹1,00,000</p>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-400 mb-2">Payment Method</label>
                                <div class="space-y-2">
                                    <div class="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer">
                                        <input type="radio" id="upi" name="payment_method" value="upi" class="mr-3" checked>
                                        <label for="upi" class="flex items-center flex-1 cursor-pointer">
                                            <i class="fas fa-mobile-alt mr-3 text-blue-400 text-xl"></i>
                                            <div>
                                                <div class="font-medium">UPI</div>
                                                <div class="text-gray-400 text-sm">Google Pay, PhonePe, Paytm</div>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer">
                                        <input type="radio" id="card" name="payment_method" value="card" class="mr-3">
                                        <label for="card" class="flex items-center flex-1 cursor-pointer">
                                            <i class="far fa-credit-card mr-3 text-purple-400 text-xl"></i>
                                            <div>
                                                <div class="font-medium">Credit/Debit Card</div>
                                                <div class="text-gray-400 text-sm">Visa, MasterCard, RuPay</div>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer">
                                        <input type="radio" id="netbanking" name="payment_method" value="netbanking" class="mr-3">
                                        <label for="netbanking" class="flex items-center flex-1 cursor-pointer">
                                            <i class="fas fa-university mr-3 text-green-400 text-xl"></i>
                                            <div>
                                                <div class="font-medium">Net Banking</div>
                                                <div class="text-gray-400 text-sm">All major Indian banks</div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-end gap-2">
                                <button type="button" id="cancelDeposit" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition">
                                    Cancel
                                </button>
                                <button type="submit" name="deposit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition">
                                    Proceed to Pay
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Withdrawal Modal -->
                <div id="withdrawModal" class="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 hidden fade-in">
                    <div class="bg-gray-800 rounded-xl p-6 w-full max-w-md mx-4">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-yellow-400">Withdraw Money</h3>
                            <button id="closeWithdrawModal" class="text-gray-400 hover:text-white text-xl">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <form method="POST" action="my_wallet.php" id="withdrawForm">
                            <div class="mb-4">
                                <label class="block text-gray-400 mb-2">Amount (₹)</label>
                                <input 
                                    type="number" 
                                    name="amount" 
                                    min="100" 
                                    step="0.01" 
                                    max="<?php echo $current_balance; ?>"
                                    class="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500" 
                                    placeholder="Enter amount"
                                    required
                                >
                                <p class="text-gray-500 text-sm mt-1">Available: ₹<?php echo number_format($current_balance, 2); ?></p>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-400 mb-2">Withdrawal Method</label>
                                <div class="space-y-2">
                                    <div class="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer">
                                        <input type="radio" id="bank" name="withdrawal_method" value="bank" class="mr-3" checked>
                                        <label for="bank" class="flex items-center flex-1 cursor-pointer">
                                            <i class="fas fa-university mr-3 text-green-400 text-xl"></i>
                                            <div>
                                                <div class="font-medium">Bank Transfer</div>
                                                <div class="text-gray-400 text-sm">Direct to your bank account</div>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 cursor-pointer">
                                        <input type="radio" id="upi_withdraw" name="withdrawal_method" value="upi" class="mr-3">
                                        <label for="upi_withdraw" class="flex items-center flex-1 cursor-pointer">
                                            <i class="fas fa-mobile-alt mr-3 text-blue-400 text-xl"></i>
                                            <div>
                                                <div class="font-medium">UPI</div>
                                                <div class="text-gray-400 text-sm">Instant UPI transfer</div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="bg-yellow-900 border border-yellow-700 rounded-lg p-3 mb-4">
                                <div class="flex items-start">
                                    <i class="fas fa-info-circle text-yellow-400 mt-1 mr-2"></i>
                                    <div class="text-yellow-200 text-sm">
                                        <strong>Note:</strong> Withdrawals are processed within 24-48 hours. Minimum withdrawal amount is ₹100.
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-end gap-2">
                                <button type="button" id="cancelWithdraw" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition">
                                    Cancel
                                </button>
                                <button type="submit" name="withdraw" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition">
                                    Request Withdrawal
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-gray-800 rounded-xl p-6 shadow-lg fade-in">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold text-yellow-400">Recent Transactions</h3>
                        <span class="text-yellow-400 text-sm flex items-center gap-1">
                            Last 10 Transactions
                        </span>
                    </div>
                    
                    <?php if (count($transactions) > 0): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead>
                                    <tr class="border-b border-gray-700">
                                        <th class="py-3 px-4">Date & Time</th>
                                        <th class="py-3 px-4">Type</th>
                                        <th class="py-3 px-4">Amount</th>
                                        <th class="py-3 px-4">Method</th>
                                        <th class="py-3 px-4">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $transaction): ?>
                                        <tr class="border-b border-gray-700 hover:bg-gray-750 transition">
                                            <td class="py-3 px-4">
                                                <div class="text-sm"><?php echo date('d M Y', strtotime($transaction['created_at'])); ?></div>
                                                <div class="text-xs text-gray-400"><?php echo date('h:i A', strtotime($transaction['created_at'])); ?></div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <span class="inline-flex items-center gap-1">
                                                    <?php if ($transaction['type'] === 'deposit'): ?>
                                                        <i class="fas fa-arrow-down text-green-500"></i>
                                                        <span class="text-green-500 font-medium">Deposit</span>
                                                    <?php else: ?>
                                                        <i class="fas fa-arrow-up text-red-500"></i>
                                                        <span class="text-red-500 font-medium">Withdrawal</span>
                                                    <?php endif; ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-4 font-semibold">
                                                ₹<?php echo number_format($transaction['amount'], 2); ?>
                                            </td>
                                            <td class="py-3 px-4 text-sm text-gray-300 capitalize">
                                                <?php echo $transaction['payment_method']; ?>
                                            </td>
                                            <td class="py-3 px-4">
                                                <?php 
                                                $status_class = '';
                                                if ($transaction['status'] === 'completed') {
                                                    $status_class = 'bg-green-800 text-green-200';
                                                } elseif ($transaction['status'] === 'pending') {
                                                    $status_class = 'bg-yellow-800 text-yellow-200';
                                                } else {
                                                    $status_class = 'bg-red-800 text-red-200';
                                                }
                                                ?>
                                                <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $status_class; ?>">
                                                    <?php echo ucfirst($transaction['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-12">
                            <i class="fas fa-exchange-alt text-5xl text-gray-600 mb-4"></i>
                            <p class="text-gray-500 text-lg mb-2">No transactions yet</p>
                            <p class="text-gray-600">Your transaction history will appear here</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Deposit Modal
        const depositBtn = document.getElementById('depositBtn');
        const depositModal = document.getElementById('depositModal');
        const closeDepositModal = document.getElementById('closeDepositModal');
        const cancelDeposit = document.getElementById('cancelDeposit');

        depositBtn.addEventListener('click', () => {
            depositModal.classList.remove('hidden');
        });

        closeDepositModal.addEventListener('click', () => {
            depositModal.classList.add('hidden');
        });

        cancelDeposit.addEventListener('click', () => {
            depositModal.classList.add('hidden');
        });

        // Withdrawal Modal
        const withdrawBtn = document.getElementById('withdrawBtn');
        const withdrawModal = document.getElementById('withdrawModal');
        const closeWithdrawModal = document.getElementById('closeWithdrawModal');
        const cancelWithdraw = document.getElementById('cancelWithdraw');

        withdrawBtn.addEventListener('click', () => {
            withdrawModal.classList.remove('hidden');
        });

        closeWithdrawModal.addEventListener('click', () => {
            withdrawModal.classList.add('hidden');
        });

        cancelWithdraw.addEventListener('click', () => {
            withdrawModal.classList.add('hidden');
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === depositModal) {
                depositModal.classList.add('hidden');
            }
            if (e.target === withdrawModal) {
                withdrawModal.classList.add('hidden');
            }
        });

        // Form validation
        document.getElementById('depositForm').addEventListener('submit', function(e) {
            const amount = this.amount.value;
            if (amount < 1 || amount > 100000) {
                e.preventDefault();
                alert('Please enter an amount between ₹1 and ₹1,00,000');
            }
        });

        document.getElementById('withdrawForm').addEventListener('submit', function(e) {
            const amount = parseFloat(this.amount.value);
            const maxAmount = parseFloat(this.amount.max);
            
            if (amount < 100) {
                e.preventDefault();
                alert('Minimum withdrawal amount is ₹100');
            } else if (amount > maxAmount) {
                e.preventDefault();
                alert('Insufficient balance for this withdrawal');
            }
        });

        // Enhanced radio button selection
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                // Remove all active classes
                this.closest('.space-y-2').querySelectorAll('.bg-gray-600').forEach(el => {
                    el.classList.remove('bg-gray-600');
                    el.classList.add('bg-gray-700');
                });
                
                // Add active class to selected
                this.closest('.bg-gray-700').classList.remove('bg-gray-700');
                this.closest('.bg-gray-700, .bg-gray-600').classList.add('bg-gray-600');
            });
        });
    </script>
</body>
</html>