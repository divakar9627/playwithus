<?php
session_start();
include '../../includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tournaments - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Simple Navigation -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">
                <a href="../../index.php">PlayWithUs</a>
            </div>
            <div class="flex space-x-4">
                <a href="my_profile.php" class="text-yellow-400 hover:text-yellow-300">My Profile</a>
                <a href="../../index.php" class="text-yellow-400 hover:text-yellow-300">Home</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-300">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Tournaments Section -->
    <section class="py-12 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-6xl mx-auto">
                <!-- Header -->
                <div class="text-center mb-12">
                    <h1 class="text-4xl font-bold text-yellow-400 mb-4">My Tournaments</h1>
                    <p class="text-gray-400 text-lg">Track your tournament participation and results</p>
                </div>

                <!-- Tournament Stats -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-gray-800 p-6 rounded-xl text-center">
                        <i class="fas fa-trophy text-4xl text-yellow-500 mb-3"></i>
                        <h3 class="text-2xl font-bold text-white">0</h3>
                        <p class="text-gray-400">Tournaments Joined</p>
                    </div>
                    <div class="bg-gray-800 p-6 rounded-xl text-center">
                        <i class="fas fa-medal text-4xl text-yellow-500 mb-3"></i>
                        <h3 class="text-2xl font-bold text-white">0</h3>
                        <p class="text-gray-400">Wins</p>
                    </div>
                    <div class="bg-gray-800 p-6 rounded-xl text-center">
                        <i class="fas fa-coins text-4xl text-yellow-500 mb-3"></i>
                        <h3 class="text-2xl font-bold text-white">₹0</h3>
                        <p class="text-gray-400">Total Earnings</p>
                    </div>
                    <div class="bg-gray-800 p-6 rounded-xl text-center">
                        <i class="fas fa-ranking-star text-4xl text-yellow-500 mb-3"></i>
                        <h3 class="text-2xl font-bold text-white">#-</h3>
                        <p class="text-gray-400">Current Rank</p>
                    </div>
                </div>

                <!-- Tournaments List -->
                <div class="bg-gray-800 rounded-xl p-8 shadow-lg">
                    <h3 class="text-2xl font-bold text-yellow-400 mb-6">Your Tournament History</h3>
                    
                    <!-- Empty State -->
                    <div class="text-center py-12">
                        <i class="fas fa-trophy text-6xl text-gray-600 mb-4"></i>
                        <h4 class="text-xl font-semibold text-gray-400 mb-2">No Tournaments Yet</h4>
                        <p class="text-gray-500 mb-6">You haven't joined any tournaments yet.</p>
                        <a href="../../join_tournament.php" class="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-6 rounded-lg transition duration-300">
                            <i class="fas fa-plus mr-2"></i>Join Tournament
                        </a>
                    </div>

                    <!-- Sample Tournaments (Will be dynamic later) -->
                    <!--
                    <div class="space-y-4">
                        <div class="bg-gray-700 p-4 rounded-lg flex justify-between items-center">
                            <div>
                                <h4 class="text-lg font-semibold text-white">PUBG Squad Battle</h4>
                                <p class="text-gray-400">Entry: ₹100 | Prize: ₹5000</p>
                            </div>
                            <span class="bg-green-500 text-white px-3 py-1 rounded-full text-sm">Completed</span>
                        </div>
                    </div>
                    -->
                </div>

                <!-- Quick Actions -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                    <a href="../../join_tournament.php" class="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-6 rounded-xl transition duration-300 text-center">
                        <i class="fas fa-plus mr-2"></i>Join New Tournament
                    </a>
                    <a href="my_profile.php" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-4 px-6 rounded-xl transition duration-300 text-center">
                        <i class="fas fa-user mr-2"></i>Back to Profile
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>