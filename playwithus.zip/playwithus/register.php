<?php
session_start();
include 'includes/config.php';

$username = $email = $phone = $game_preference = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $game_preference = $_POST['game_preference'];
    $phone = trim($_POST['phone']);
    
    // Validation
    if (empty($username)) {
        $errors['username'] = 'Username is required';
    } elseif (strlen($username) < 3) {
        $errors['username'] = 'Username must be at least 3 characters';
    } else {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->rowCount() > 0) {
            $errors['username'] = 'Username already taken';
        }
    }
    
    if (empty($email)) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            $errors['email'] = 'Email already registered';
        }
    }
    
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'Password must be at least 6 characters';
    }
    
    if ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Passwords do not match';
    }
    
    if (!empty($phone)) {
        // Check if phone number already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        if ($stmt->rowCount() > 0) {
            $errors['phone'] = 'Phone number already registered';
        }
    }
    
    if (!isset($_POST['terms'])) {
        $errors['terms'] = 'You must agree to terms and conditions';
    }
    
    // If no errors, send OTP for email verification
    if (empty($errors)) {
        // Generate OTP
        $otp = rand(100000, 999999);
        
        // Store data in session for verification
        $_SESSION['registration_data'] = [
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'game_preference' => $game_preference,
            'phone' => $phone,
            'otp' => $otp,
            'otp_expiry' => time() + 600 // 10 minutes
        ];
        
        // Send OTP via Email
        $email_sent = sendVerificationEmail($email, $username, $otp);
        
        if ($email_sent) {
            $_SESSION['verification_pending'] = true;
            header('Location: verify-email.php');
            exit();
        } else {
            $errors['email'] = 'Failed to send verification email. Please try again.';
        }
    }
}

// Email sending function
function sendVerificationEmail($to_email, $username, $otp) {
    require_once 'smtp/src/PHPMailer.php';
    require_once 'smtp/src/SMTP.php';
    require_once 'smtp/src/Exception.php';
    
    $subject = "Email Verification - PlayWithUs";
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; border-radius: 10px 10px 0 0; color: white; }
            .otp-code { font-size: 32px; font-weight: bold; text-align: center; margin: 30px 0; color: #333; background: #f8f9fa; padding: 15px; border-radius: 8px; letter-spacing: 5px; border: 2px dashed #667eea; }
            .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666; }
            .note { background: #fff3cd; padding: 10px; border-radius: 5px; border-left: 4px solid #ffc107; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🎮 PlayWithUs</h1>
                <p>Email Verification</p>
            </div>
            
            <h2>Welcome {$username}!</h2>
            <p>Thank you for registering with PlayWithUs. Use the following OTP to verify your email address:</p>
            
            <div class='otp-code'>{$otp}</div>
            
            <div class='note'>
                <strong>Note:</strong> This OTP is valid for <strong>10 minutes</strong>. 
                Do not share this code with anyone.
            </div>
            
            <p>If you didn't create an account with PlayWithUs, please ignore this email.</p>
            
            <div class='footer'>
                <p>Happy Gaming! 🎮</p>
                <p><strong>PlayWithUs Team</strong></p>
                <p><small>This is an automated message, please do not reply to this email.</small></p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(); 
        $mail->isSMTP(); 
        $mail->SMTPAuth = true; 
        $mail->SMTPSecure = 'tls'; 
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587; 
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        
        // 🔹 YOUR GMAIL CREDENTIALS
        $mail->Username = "divakarjha7777@gmail.com"; // अपना Gmail डालें
        $mail->Password = "emhl hyqf bwyy uoeu"; // Your App Password
        $mail->setFrom("divakarjha7777@gmail.com", "PlayWithUs");
        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->addAddress($to_email);
        
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Email Error: " . $e->getMessage());
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Navigation Bar -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">PlayWithUs</div>
            <ul class="flex space-x-6">
                <li><a href="index.php" class="hover:text-yellow-400">Home</a></li>
                <li><a href="create_tournament.php" class="hover:text-yellow-400">Create Tournament</a></li>
                <li><a href="join_tournament.php" class="hover:text-yellow-400">Join Tournament</a></li>
                <li><a href="leaderboard.php" class="hover:text-yellow-400">Leaderboard</a></li>
                <li><a href="login.php" class="hover:text-yellow-400">Login</a></li>
                <li><a href="register.php" class="hover:text-yellow-400 font-bold">Register</a></li>
            </ul>
        </div>
    </nav>

    <!-- Registration Section -->
    <section class="py-16 bg-gray-900">
        <div class="container mx-auto px-4">
            <div class="max-w-md mx-auto bg-gray-800 rounded-lg shadow-lg p-8">
                <h2 class="text-3xl font-bold text-center text-yellow-400 mb-8">Create Your Account</h2>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="bg-green-600 text-white p-3 rounded mb-4">
                        <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($errors['database'])): ?>
                    <div class="bg-red-600 text-white p-3 rounded mb-4">
                        <?= $errors['database'] ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($errors['email']) && strpos($errors['email'], 'Failed to send') !== false): ?>
                    <div class="bg-red-600 text-white p-3 rounded mb-4">
                        <?= $errors['email'] ?>
                    </div>
                <?php endif; ?>
                
                <form action="register.php" method="POST">
                    <div class="mb-6">
                        <label for="username" class="block text-gray-300 mb-2">Username</label>
                        <input type="text" id="username" name="username" value="<?= htmlspecialchars($username) ?>" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['username']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['username'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['username'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6">
                        <label for="email" class="block text-gray-300 mb-2">Email Address</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['email']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['email'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['email'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6">
                        <label for="password" class="block text-gray-300 mb-2">Password</label>
                        <input type="password" id="password" name="password" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['password']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['password'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['password'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6">
                        <label for="confirm_password" class="block text-gray-300 mb-2">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['confirm_password']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['confirm_password'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['confirm_password'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6">
                        <label for="game_preference" class="block text-gray-300 mb-2">Preferred Game</label>
                        <select id="game_preference" name="game_preference" 
                                class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                            <option value="pubg" <?= $game_preference == 'pubg' ? 'selected' : '' ?>>PUBG</option>
                            <option value="freefire" <?= $game_preference == 'freefire' ? 'selected' : '' ?>>Free Fire</option>
                            <option value="both" <?= $game_preference == 'both' ? 'selected' : '' ?>>Both</option>
                        </select>
                    </div>
                    
                    <div class="mb-6">
                        <label for="phone" class="block text-gray-300 mb-2">Phone Number</label>
                        <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($phone) ?>" 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['phone']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['phone'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['phone'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6 flex items-center">
                        <input type="checkbox" id="terms" name="terms" 
                               class="w-4 h-4 text-yellow-500 bg-gray-700 border-gray-600 rounded focus:ring-yellow-500">
                        <label for="terms" class="ml-2 text-gray-300">
                            I agree to the <a href="#" class="text-yellow-400 hover:underline">Terms & Conditions</a>
                        </label>
                        <?php if (isset($errors['terms'])): ?>
                            <p class="text-red-400 text-sm mt-1 ml-2"><?= $errors['terms'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" 
                            class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-4 rounded-lg transition duration-300">
                        <i class="fas fa-user-plus mr-2"></i>Create Account
                    </button>
                </form>
                
                <div class="mt-6 text-center">
                    <p class="text-gray-400">
                        Already have an account? 
                        <a href="login.php" class="text-yellow-400 hover:underline">Login here</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Rest of your existing code remains same -->
</body>
</html>