<?php
include 'config.php';

function sendOTPEmail($email, $otp, $userName = 'User') {
    try {
        // Simple mail function for testing
        $subject = 'Password Reset OTP - ' . SITE_NAME;
        $message = "
            <html>
            <head>
                <title>Password Reset OTP</title>
            </head>
            <body>
                <h2>Hello $userName,</h2>
                <p>You requested to reset your password for your " . SITE_NAME . " account.</p>
                <p>Your OTP code is: <strong style='font-size: 24px; color: #2563eb;'>$otp</strong></p>
                <p>This OTP will expire in 10 minutes.</p>
                <p>If you didn't request this, please ignore this email.</p>
                <br>
                <p>Best regards,<br>" . SITE_NAME . " Team</p>
            </body>
            </html>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: " . SITE_NAME . " <" . SMTP_USER . ">" . "\r\n";
        
        // For testing - log the email instead of sending
        if (SMTP_USER === 'youremail@gmail.com') {
            error_log("OTP Email for $email: $otp");
            return true; // Testing ke liye always true return karega
        }
        
        return mail($email, $subject, $message, $headers);
        
    } catch (Exception $e) {
        error_log("Email sending failed: " . $e->getMessage());
        return false;
    }
}

// ✅ NEW: Advanced mail function with PHPMailer (optional)
function sendOTPEmailAdvanced($email, $otp, $userName = 'User') {
    // Check if PHPMailer is available
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        return sendOTPEmail($email, $otp, $userName); // Fallback to simple mail
    }
    
    require 'vendor/autoload.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_USER, SITE_NAME);
        $mail->addAddress($email, $userName);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset OTP - ' . SITE_NAME;
        $mail->Body    = "
            <h2>Hello $userName,</h2>
            <p>You requested to reset your password for your " . SITE_NAME . " account.</p>
            <p>Your OTP code is: <strong style='font-size: 24px; color: #2563eb;'>$otp</strong></p>
            <p>This OTP will expire in 10 minutes.</p>
            <p>If you didn't request this, please ignore this email.</p>
            <br>
            <p>Best regards,<br>" . SITE_NAME . " Team</p>
        ";
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return sendOTPEmail($email, $otp, $userName); // Fallback to simple mail
    }
}
?>