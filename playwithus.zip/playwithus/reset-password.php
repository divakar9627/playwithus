<?php 
session_start();
include 'includes/config.php';

// Check if token is valid
$token = $_GET['token'] ?? '';

if (!isset($_SESSION['reset_token']) || $_SESSION['reset_token'] !== $token) {
    header('Location: forgot_password.php?error=invalid_token');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 min-h-screen flex items-center justify-center p-4">
    <div class="bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md border border-gray-700">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-lock text-2xl text-black"></i>
            </div>
            <h1 class="text-3xl font-bold text-yellow-400 mb-2">Reset Password</h1>
            <p class="text-gray-400">Create your new password</p>
        </div>

        <!-- Message Display -->
        <div id="message" class="hidden p-4 rounded-lg mb-6 text-center text-lg font-semibold"></div>

        <form id="resetForm">
            <input type="hidden" name="token" id="tokenField" value="<?= htmlspecialchars($token) ?>">
            
            <div class="mb-6">
                <label class="block text-gray-300 mb-3 text-lg font-semibold">
                    <i class="fas fa-lock mr-2 text-yellow-400"></i>New Password
                </label>
                <input type="password" name="new_password" required 
                       class="w-full px-4 py-4 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg transition duration-300"
                       placeholder="Enter new password"
                       minlength="6">
                <p class="text-gray-400 text-sm mt-2">Minimum 6 characters</p>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-300 mb-3 text-lg font-semibold">
                    <i class="fas fa-lock mr-2 text-yellow-400"></i>Confirm Password
                </label>
                <input type="password" name="confirm_password" required 
                       class="w-full px-4 py-4 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg transition duration-300"
                       placeholder="Confirm new password"
                       minlength="6">
            </div>
            
            <button type="submit" 
                    class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 mb-4">
                <i class="fas fa-save mr-3"></i>Reset Password
            </button>
        </form>

        <div class="text-center mt-6 pt-6 border-t border-gray-700">
            <a href="login.php" class="text-yellow-400 hover:text-yellow-300 hover:underline font-semibold transition duration-300">
                <i class="fas fa-sign-in-alt mr-1"></i>Back to Login
            </a>
        </div>
    </div>

    <script>
    function showMessage(message, type = 'error') {
        const messageDiv = document.getElementById('message');
        messageDiv.classList.remove('hidden', 'bg-green-600', 'bg-red-600', 'bg-yellow-600');
        
        if (type === 'success') {
            messageDiv.classList.add('bg-green-600');
        } else if (type === 'error') {
            messageDiv.classList.add('bg-red-600');
        } else {
            messageDiv.classList.add('bg-yellow-600');
        }
        
        messageDiv.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} mr-2"></i> ${message}`;
        messageDiv.classList.remove('hidden');
    }

    document.getElementById('resetForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const button = this.querySelector('button');
        
        // Get passwords
        const newPassword = formData.get('new_password');
        const confirmPassword = formData.get('confirm_password');
        
        // Client-side validation
        if (newPassword !== confirmPassword) {
            showMessage('Passwords do not match! Please check again.', 'error');
            return;
        }
        
        if (newPassword.length < 6) {
            showMessage('Password must be at least 6 characters long!', 'error');
            return;
        }
        
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Resetting Password...';
        
        try {
            const response = await fetch('update-password.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if(data.success) {
                showMessage(data.message, 'success');
                setTimeout(() => {
                    window.location.href = 'login.php?success=password_reset';
                }, 2000);
            } else {
                showMessage(data.message, 'error');
            }
            
        } catch (error) {
            console.error('Error:', error);
            showMessage('Network error: Please check your connection and try again.', 'error');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-save mr-3"></i>Reset Password';
        }
    });

    // Real-time password match checking
    document.querySelectorAll('input[type="password"]').forEach(input => {
        input.addEventListener('input', function() {
            const newPassword = document.querySelector('input[name="new_password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
            
            if (confirmPassword && newPassword !== confirmPassword) {
                document.querySelector('input[name="confirm_password"]').classList.add('border-red-500');
            } else {
                document.querySelector('input[name="confirm_password"]').classList.remove('border-red-500');
            }
        });
    });
    </script>
</body>
</html>