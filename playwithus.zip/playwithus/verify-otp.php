<?php
session_start();
include 'includes/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';
    
    // Debug information
    error_log("OTP Verification Attempt:");
    error_log("Email: " . $email);
    error_log("Submitted OTP: " . $otp);
    error_log("Session OTP: " . ($_SESSION['otp'] ?? 'NOT SET'));
    error_log("Session Email: " . ($_SESSION['otp_email'] ?? 'NOT SET'));
    error_log("Session Expiry: " . ($_SESSION['otp_expiry'] ?? 'NOT SET'));
    error_log("Current Time: " . time());
    
    // Verify OTP from session
    if (isset($_SESSION['otp']) && 
        isset($_SESSION['otp_email']) && 
        isset($_SESSION['otp_expiry'])) {
        
        // Check if OTP matches and is not expired
        if ($_SESSION['otp_email'] === $email &&
            $_SESSION['otp'] === $otp &&
            time() < $_SESSION['otp_expiry']) {
            
            // Generate reset token
            $reset_token = bin2hex(random_bytes(32));
            $_SESSION['reset_token'] = $reset_token;
            $_SESSION['reset_email'] = $email;
            
            // Clear OTP session
            unset($_SESSION['otp']);
            unset($_SESSION['otp_email']);
            unset($_SESSION['otp_expiry']);
            
            echo json_encode([
                'success' => true,
                'message' => 'OTP verified successfully!',
                'token' => $reset_token
            ]);
            
        } else {
            // Detailed error message
            $error_msg = 'Invalid OTP. ';
            
            if ($_SESSION['otp_email'] !== $email) {
                $error_msg .= 'Email mismatch. ';
            }
            if ($_SESSION['otp'] !== $otp) {
                $error_msg .= 'OTP code incorrect. ';
            }
            if (time() >= $_SESSION['otp_expiry']) {
                $error_msg .= 'OTP has expired. ';
            }
            
            echo json_encode([
                'success' => false,
                'message' => trim($error_msg)
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'OTP session not found. Please request a new OTP.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>