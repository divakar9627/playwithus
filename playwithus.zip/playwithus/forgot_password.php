

<?php
// forgotpassword.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password - PlayWithUs</title>
  <link rel="stylesheet" href="assets/css/tailwind.css">
  <link rel="stylesheet" href="assets/css/tailwind.css">
  <script src="https://cdn.tailwindcss.com"></script>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>


<body class="bg-gray-900 text-white font-sans">

    <!-- Navigation Bar -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">
                <i class="fas fa-gamepad mr-2"></i>PlayWithUs
            </div>
            <ul class="flex space-x-6">
                <li><a href="index.php" class="hover:text-yellow-400 transition duration-300">Home</a></li>
                <li><a href="login.php" class="hover:text-yellow-400 transition duration-300">Login</a></li>
                <li><a href="register.php" class="hover:text-yellow-400 transition duration-300">Register</a></li>
            </ul>
        </div>
    </nav>

    <!-- Forgot Password Section -->
    <section class="py-16 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-md mx-auto bg-gray-800 rounded-xl shadow-2xl p-8 border border-gray-700">
                <!-- Header -->
                <div class="text-center mb-8">
                    <div class="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-key text-2xl text-black"></i>
                    </div>
                    <h1 class="text-3xl font-bold text-yellow-400 mb-2">Forgot Password</h1>
                    <p class="text-gray-400 text-lg">Reset your account password</p>
                </div>

                <!-- Message Display -->
                <div id="message" class="hidden p-4 rounded-lg mb-6 text-center text-lg font-semibold"></div>

                <!-- Email Form -->
                <form id="forgotForm">
                    <div class="mb-6">
                        <label class="block text-gray-300 mb-3 text-lg font-semibold">
                            <i class="fas fa-envelope mr-2 text-yellow-400"></i>Email Address
                        </label>
                        <input type="email" name="email" required 
                               class="w-full px-4 py-4 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg transition duration-300"
                               placeholder="Enter your registered email">
                    </div>
                    
                    <button type="submit" 
                            class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                        <i class="fas fa-paper-plane mr-3"></i>Send OTP
                    </button>
                </form>

                <!-- OTP Form -->
                <div id="otpSection" class="hidden mt-8 pt-8 border-t border-gray-700">
                    <div class="text-center mb-6">
                        <h3 class="text-2xl font-bold text-yellow-400 mb-2">
                            <i class="fas fa-mobile-alt mr-2"></i>Enter OTP
                        </h3>
                        <p class="text-gray-400" id="otpInfo">Check your email for the verification code</p>
                    </div>
                    
                    <form id="otpForm">
                        <div class="mb-6">
                            <input type="text" name="otp" required 
                                   class="w-full px-4 py-4 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg text-center tracking-widest transition duration-300"
                                   placeholder="Enter 6-digit OTP"
                                   maxlength="6"
                                   pattern="[0-9]{6}">
                            <p class="text-gray-400 text-sm mt-3 text-center">
                                <i class="fas fa-info-circle mr-1"></i>Enter the 6-digit code sent to your email
                            </p>
                        </div>
                        <input type="hidden" name="email" id="emailField">
                        
                        <button type="submit" 
                                class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                            <i class="fas fa-check-circle mr-3"></i>Verify OTP
                        </button>
                    </form>
                </div>

                <!-- Back to Login -->
                <div class="text-center mt-8 pt-6 border-t border-gray-700">
                    <p class="text-gray-400 text-lg">
                        Remember your password? 
                        <a href="login.php" class="text-yellow-400 hover:text-yellow-300 hover:underline font-semibold transition duration-300">
                            <i class="fas fa-sign-in-alt mr-1"></i>Login here
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-16 bg-gray-800">
        <div class="container mx-auto text-center px-4">
            <h2 class="text-4xl font-bold mb-12 text-yellow-400">Why Choose PlayWithUs?</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-gray-700 p-8 rounded-xl shadow-lg hover:shadow-2xl transition duration-300 transform hover:-translate-y-2">
                    <i class="fas fa-shield-alt text-5xl text-yellow-500 mb-6"></i>
                    <h3 class="text-2xl font-semibold mb-4 text-white">Secure Recovery</h3>
                    <p class="text-gray-300 text-lg">Your account security is our top priority with encrypted password reset process.</p>
                </div>
                <div class="bg-gray-700 p-8 rounded-xl shadow-lg hover:shadow-2xl transition duration-300 transform hover:-translate-y-2">
                    <i class="fas fa-bolt text-5xl text-yellow-500 mb-6"></i>
                    <h3 class="text-2xl font-semibold mb-4 text-white">Instant OTP</h3>
                    <p class="text-gray-300 text-lg">Receive OTP instantly and get back to gaming within minutes.</p>
                </div>
                <div class="bg-gray-700 p-8 rounded-xl shadow-lg hover:shadow-2xl transition duration-300 transform hover:-translate-y-2">
                    <i class="fas fa-trophy text-5xl text-yellow-500 mb-6"></i>
                    <h3 class="text-2xl font-semibold mb-4 text-white">Premium Tournaments</h3>
                    <p class="text-gray-300 text-lg">Join exclusive PUBG & Free Fire tournaments with big prize pools.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 py-12">
        <div class="container mx-auto text-center px-4">
            <div class="text-3xl font-bold text-yellow-400 mb-4">
                <i class="fas fa-gamepad mr-2"></i>PlayWithUs
            </div>
            <p class="text-gray-400 text-lg mb-6">Join the ultimate gaming experience with PUBG & Free Fire tournaments</p>
            <div class="flex justify-center space-x-6 mb-6">
                <a href="#" class="text-yellow-400 hover:text-white text-2xl transition duration-300 transform hover:scale-110">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="#" class="text-yellow-400 hover:text-white text-2xl transition duration-300 transform hover:scale-110">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="text-yellow-400 hover:text-white text-2xl transition duration-300 transform hover:scale-110">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="#" class="text-yellow-400 hover:text-white text-2xl transition duration-300 transform hover:scale-110">
                    <i class="fab fa-discord"></i>
                </a>
            </div>
            <p class="text-gray-500">&copy; 2023 PlayWithUs. All rights reserved.</p>
        </div>
    </footer>

    <script>
    let generatedOTP = '';

    function showMessage(message, type = 'info') {
        const messageDiv = document.getElementById('message');
        messageDiv.classList.remove('hidden', 'bg-green-600', 'bg-red-600', 'bg-yellow-600');
        
        if (type === 'success') {
            messageDiv.classList.add('bg-green-600');
            messageDiv.innerHTML = `<i class="fas fa-check-circle mr-2"></i> ${message}`;
        } else if (type === 'error') {
            messageDiv.classList.add('bg-red-600');
            messageDiv.innerHTML = `<i class="fas fa-exclamation-circle mr-2"></i> ${message}`;
        } else {
            messageDiv.classList.add('bg-yellow-600');
            messageDiv.innerHTML = `<i class="fas fa-info-circle mr-2"></i> ${message}`;
        }
        
        messageDiv.classList.remove('hidden');
    }

    function generateOTP() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    }

    // Email Form Submission
    document.getElementById('forgotForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const button = this.querySelector('button');
        const email = formData.get('email');
        
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending OTP...';
        showMessage('Sending OTP to your email address...', 'info');
        
        try {
            // Generate OTP
            generatedOTP = generateOTP();
            
            // Send OTP request to server
            const response = await fetch('send-otp.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}&otp=${generatedOTP}`
            });
            
            const data = await response.json();
            
            if(data.success) {
                document.getElementById('otpSection').classList.remove('hidden');
                document.getElementById('emailField').value = email;
                document.getElementById('otpInfo').innerHTML = `OTP sent to <span class="text-yellow-400">${email}</span>. For testing, use OTP: <span class="text-green-400 font-bold">${generatedOTP}</span>`;
                showMessage(data.message, 'success');
            } else {
                showMessage(data.message, 'error');
            }
            
        } catch (error) {
            console.error('Error:', error);
            showMessage('Network error: Please try again.', 'error');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-paper-plane mr-2"></i>Send OTP';
        }
    });

    // OTP Form Submission
    document.getElementById('otpForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const button = this.querySelector('button');
        const otp = formData.get('otp');
        const email = formData.get('email');
        
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';
        showMessage('Verifying OTP code...', 'info');
        
        try {
            // Verify OTP with server
            const response = await fetch('verify-otp.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}&otp=${otp}`
            });
            
            const data = await response.json();
            
            if(data.success) {
                showMessage('OTP verified successfully! Redirecting to password reset...', 'success');
                setTimeout(() => {
                    window.location.href = 'reset-password.php?token=' + data.token;
                }, 1500);
            } else {
                showMessage(data.message, 'error');
            }
            
        } catch (error) {
            console.error('Error:', error);
            showMessage('Network error: Please try again.', 'error');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Verify OTP';
        }
    });
    </script>
</body>
</html>