<?php
session_start();
include 'includes/config.php';

// Check if user is logged in AND is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    $_SESSION['error'] = 'Access denied. Only administrators can create tournaments.';
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Initialize form fields
$tournament_data = [
    'title' => '',
    'game_type' => 'pubg',
    'entry_fee' => '',
    'prize_pool' => '',
    'max_participants' => '',
    'start_date' => '',
    'start_time' => '',
    'description' => '',
    'rules' => '',
    'contact_info' => ''
];

// Handle tournament creation
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input data
    $tournament_data = [
        'title' => trim($_POST['title'] ?? ''),
        'game_type' => $_POST['game_type'] ?? 'pubg',
        'entry_fee' => trim($_POST['entry_fee'] ?? ''),
        'prize_pool' => trim($_POST['prize_pool'] ?? ''),
        'max_participants' => trim($_POST['max_participants'] ?? ''),
        'start_date' => $_POST['start_date'] ?? '',
        'start_time' => $_POST['start_time'] ?? '',
        'description' => trim($_POST['description'] ?? ''),
        'rules' => trim($_POST['rules'] ?? ''),
        'contact_info' => trim($_POST['contact_info'] ?? '')
    ];

    // Validation
    if (empty($tournament_data['title'])) {
        $errors['title'] = 'Tournament title is required';
    } elseif (strlen($tournament_data['title']) < 5) {
        $errors['title'] = 'Title must be at least 5 characters';
    }

    if (empty($tournament_data['entry_fee']) || !is_numeric($tournament_data['entry_fee']) || $tournament_data['entry_fee'] < 0) {
        $errors['entry_fee'] = 'Valid entry fee is required';
    }

    if (empty($tournament_data['prize_pool']) || !is_numeric($tournament_data['prize_pool']) || $tournament_data['prize_pool'] < 0) {
        $errors['prize_pool'] = 'Valid prize pool is required';
    }

    if (empty($tournament_data['max_participants']) || !is_numeric($tournament_data['max_participants']) || $tournament_data['max_participants'] < 2) {
        $errors['max_participants'] = 'Valid number of participants is required (minimum 2)';
    }

    if (empty($tournament_data['start_date'])) {
        $errors['start_date'] = 'Start date is required';
    } else {
        $start_datetime = $tournament_data['start_date'] . ' ' . ($tournament_data['start_time'] ?: '00:00');
        if (strtotime($start_datetime) <= time()) {
            $errors['start_date'] = 'Start date must be in the future';
        }
    }

    if (empty($tournament_data['description'])) {
        $errors['description'] = 'Description is required';
    } elseif (strlen($tournament_data['description']) < 20) {
        $errors['description'] = 'Description must be at least 20 characters';
    }

    // If no errors, create tournament
    if (empty($errors)) {
        try {
            $start_datetime = $tournament_data['start_date'] . ' ' . ($tournament_data['start_time'] ?: '00:00:00');
            
            $stmt = $pdo->prepare("INSERT INTO tournaments (creator_id, title, game_type, entry_fee, prize_pool, max_participants, current_participants, start_date, description, rules, contact_info, status) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 'upcoming')");
            
            $stmt->execute([
                $user_id,
                $tournament_data['title'],
                $tournament_data['game_type'],
                $tournament_data['entry_fee'],
                $tournament_data['prize_pool'],
                $tournament_data['max_participants'],
                $start_datetime,
                $tournament_data['description'],
                $tournament_data['rules'],
                $tournament_data['contact_info']
            ]);

            $tournament_id = $pdo->lastInsertId();
            
            // Create tournament folder in admin directory
            createTournamentFolder($user_id, $tournament_id, $tournament_data);
            
            $success = 'Tournament created successfully! Players can now join your tournament.';
            
            // Reset form
            $tournament_data = [
                'title' => '',
                'game_type' => 'pubg',
                'entry_fee' => '',
                'prize_pool' => '',
                'max_participants' => '',
                'start_date' => '',
                'start_time' => '',
                'description' => '',
                'rules' => '',
                'contact_info' => ''
            ];

        } catch(PDOException $e) {
            $errors['database'] = 'Failed to create tournament: ' . $e->getMessage();
        }
    }
}

// Function to create tournament folder
function createTournamentFolder($user_id, $tournament_id, $tournament_data) {
    $tournament_folder = "admin/tournaments/{$tournament_id}";
    
    // Create tournament folder
    if (!is_dir($tournament_folder)) {
        mkdir($tournament_folder, 0777, true);
    }
    
    // Create subfolders
    $subfolders = ['participants', 'results', 'payments', 'screenshots'];
    foreach ($subfolders as $folder) {
        if (!is_dir($tournament_folder . '/' . $folder)) {
            mkdir($tournament_folder . '/' . $folder, 0777, true);
        }
    }
    
    // Save tournament info
    $tournament_info = [
        'tournament_id' => $tournament_id,
        'title' => $tournament_data['title'],
        'game_type' => $tournament_data['game_type'],
        'entry_fee' => $tournament_data['entry_fee'],
        'prize_pool' => $tournament_data['prize_pool'],
        'max_participants' => $tournament_data['max_participants'],
        'start_date' => $tournament_data['start_date'] . ' ' . ($tournament_data['start_time'] ?: '00:00'),
        'description' => $tournament_data['description'],
        'rules' => $tournament_data['rules'],
        'contact_info' => $tournament_data['contact_info'],
        'created_at' => date('Y-m-d H:i:s'),
        'created_by' => $user_id,
        'participants' => []
    ];
    
    file_put_contents($tournament_folder . '/tournament_info.json', json_encode($tournament_info, JSON_PRETTY_PRINT));
    
    return true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Tournament - PlayWithUs Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Navigation Bar -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">PlayWithUs <span class="text-sm text-red-400">Admin</span></div>
            <ul class="flex space-x-6 items-center">
                <li><a href="index.php" class="hover:text-yellow-400">Home</a></li>
                <li><a href="create_tournament.php" class="hover:text-yellow-400 font-bold">Create Tournament</a></li>
                <li><a href="join_tournament.php" class="hover:text-yellow-400">Join Tournament</a></li>
                <li><a href="leaderboard.php" class="hover:text-yellow-400">Leaderboard</a></li>
                
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="relative group">
                        <div class="flex items-center space-x-2 cursor-pointer">
                            <div class="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-sm text-black"></i>
                            </div>
                            <span class="text-yellow-400"><?= htmlspecialchars($_SESSION['username']) ?></span>
                            <span class="bg-red-500 text-white px-2 py-1 rounded-full text-xs">Admin</span>
                            <i class="fas fa-chevron-down text-yellow-400 text-xs"></i>
                        </div>
                        <div class="absolute right-0 mt-2 w-48 bg-gray-700 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                            <a href="admin/dashboard.php" class="block px-4 py-3 hover:bg-gray-600 rounded-t-lg">
                                <i class="fas fa-tachometer-alt mr-2"></i>Admin Dashboard
                            </a>
                            <a href="users/pages/my_profile.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-user mr-2"></i>My Profile
                            </a>
                            <a href="admin/manage_tournaments.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-trophy mr-2"></i>Manage Tournaments
                            </a>
                            <a href="admin/view_users.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-users mr-2"></i>View Users
                            </a>
                            <div class="border-t border-gray-600">
                                <a href="logout.php" class="block px-4 py-3 hover:bg-gray-600 rounded-b-lg text-red-400">
                                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                                </a>
                            </div>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="hover:text-yellow-400">Login</a></li>
                    <li><a href="register.php" class="hover:text-yellow-400">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <!-- Create Tournament Section -->
    <section class="py-16 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto">
                <!-- Header -->
                <div class="text-center mb-12">
                    <h1 class="text-4xl font-bold text-yellow-400 mb-4">Create Tournament <span class="text-sm text-red-400">(Admin Only)</span></h1>
                    <p class="text-gray-400 text-lg">Organize official tournaments for PlayWithUs community</p>
                </div>

                <!-- Admin Notice -->
                <div class="bg-blue-600 text-white p-4 rounded-lg mb-6">
                    <div class="flex items-center">
                        <i class="fas fa-shield-alt text-xl mr-3"></i>
                        <div>
                            <h4 class="font-bold">Administrator Access</h4>
                            <p class="text-sm">You are creating an official PlayWithUs tournament. All tournaments will be visible to all users.</p>
                        </div>
                    </div>
                </div>

                <!-- Success/Error Messages -->
                <?php if (!empty($success)): ?>
                    <div class="bg-green-600 text-white p-4 rounded-lg mb-6 text-center">
                        <?= $success ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($errors['database'])): ?>
                    <div class="bg-red-600 text-white p-4 rounded-lg mb-6">
                        <?= $errors['database'] ?>
                    </div>
                <?php endif; ?>

                <!-- Tournament Creation Form -->
                <div class="bg-gray-800 rounded-xl shadow-2xl p-8 border border-gray-700">
                    <form method="POST" class="space-y-6">
                        
                        <!-- Tournament Title -->
                        <div>
                            <label for="title" class="block text-gray-300 text-lg font-semibold mb-3">
                                <i class="fas fa-heading mr-2 text-yellow-400"></i>Tournament Title
                            </label>
                            <input type="text" id="title" name="title" 
                                   value="<?= htmlspecialchars($tournament_data['title']) ?>"
                                   class="w-full px-4 py-3 bg-gray-700 border-2 <?= isset($errors['title']) ? 'border-red-500' : 'border-gray-600' ?> rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg transition duration-300"
                                   placeholder="e.g., PUBG Squad Championship 2025"
                                   maxlength="100">
                            <?php if (isset($errors['title'])): ?>
                                <p class="text-red-400 text-sm mt-2"><?= $errors['title'] ?></p>
                            <?php else: ?>
                                <p class="text-gray-400 text-sm mt-2">Give your tournament a catchy and descriptive name</p>
                            <?php endif; ?>
                        </div>

                        <!-- Game Type and Basic Info -->
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <!-- Game Type -->
                            <div>
                                <label for="game_type" class="block text-gray-300 font-semibold mb-3">
                                    <i class="fas fa-gamepad mr-2 text-yellow-400"></i>Game
                                </label>
                                <select id="game_type" name="game_type" 
                                        class="w-full px-4 py-3 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white transition duration-300">
                                    <option value="pubg" <?= $tournament_data['game_type'] == 'pubg' ? 'selected' : '' ?>>PUBG Mobile</option>
                                    <option value="freefire" <?= $tournament_data['game_type'] == 'freefire' ? 'selected' : '' ?>>Free Fire</option>
                                    <option value="both" <?= $tournament_data['game_type'] == 'both' ? 'selected' : '' ?>>Both Games</option>
                                </select>
                            </div>

                            <!-- Entry Fee -->
                            <div>
                                <label for="entry_fee" class="block text-gray-300 font-semibold mb-3">
                                    <i class="fas fa-ticket-alt mr-2 text-yellow-400"></i>Entry Fee (₹)
                                </label>
                                <input type="number" id="entry_fee" name="entry_fee" 
                                       value="<?= htmlspecialchars($tournament_data['entry_fee']) ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border-2 <?= isset($errors['entry_fee']) ? 'border-red-500' : 'border-gray-600' ?> rounded-xl focus:outline-none focus:border-yellow-500 text-white transition duration-300"
                                       placeholder="100"
                                       min="0" step="10">
                                <?php if (isset($errors['entry_fee'])): ?>
                                    <p class="text-red-400 text-sm mt-2"><?= $errors['entry_fee'] ?></p>
                                <?php endif; ?>
                            </div>

                            <!-- Prize Pool -->
                            <div>
                                <label for="prize_pool" class="block text-gray-300 font-semibold mb-3">
                                    <i class="fas fa-trophy mr-2 text-yellow-400"></i>Prize Pool (₹)
                                </label>
                                <input type="number" id="prize_pool" name="prize_pool" 
                                       value="<?= htmlspecialchars($tournament_data['prize_pool']) ?>"
                                       class="w-full px-4 py-3 bg-gray-700 border-2 <?= isset($errors['prize_pool']) ? 'border-red-500' : 'border-gray-600' ?> rounded-xl focus:outline-none focus:border-yellow-500 text-white transition duration-300"
                                       placeholder="5000"
                                       min="0" step="100">
                                <?php if (isset($errors['prize_pool'])): ?>
                                    <p class="text-red-400 text-sm mt-2"><?= $errors['prize_pool'] ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Rest of the form remains same as previous code -->
                        <!-- ... (participants, date, description, rules, contact info sections) ... -->

                        <!-- Submit Button -->
                        <div class="pt-6">
                            <button type="submit" 
                                    class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                <i class="fas fa-plus-circle mr-3"></i>Create Official Tournament
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
</html>