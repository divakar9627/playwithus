<?php
session_start();
include 'includes/config.php';

// Check if user came from registration
if (!isset($_SESSION['verification_pending']) || !isset($_SESSION['registration_data'])) {
    header('Location: register.php');
    exit();
}

$registration_data = $_SESSION['registration_data'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $entered_otp = $_POST['otp'] ?? '';
    
    // Check if OTP matches and not expired
    if (empty($entered_otp)) {
        $errors['otp'] = 'OTP is required';
    } elseif ($entered_otp != $registration_data['otp']) {
        $errors['otp'] = 'Invalid OTP code';
    } elseif (time() > $registration_data['otp_expiry']) {
        $errors['otp'] = 'OTP has expired. Please register again.';
        unset($_SESSION['verification_pending']);
        unset($_SESSION['registration_data']);
    }
    
    // If OTP is valid, register user
    if (empty($errors)) {
        try {
            $hashed_password = password_hash($registration_data['password'], PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, game_preference, phone, email_verified) VALUES (?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                $registration_data['username'],
                $registration_data['email'], 
                $hashed_password,
                $registration_data['game_preference'],
                $registration_data['phone']
            ]);
            
            // 🔹 GET THE NEW USER ID AND CREATE USER FOLDER
            $user_id = $pdo->lastInsertId();
            createUserFolder($user_id, $registration_data);
            
            // Clear sessions
            unset($_SESSION['verification_pending']);
            unset($_SESSION['registration_data']);
            
            $_SESSION['success'] = 'Registration successful! Your email has been verified. You can now login.';
            header('Location: login.php');
            exit();
            
        } catch(PDOException $e) {
            $errors['database'] = 'Registration failed. Please try again.';
        }
    }
}

// User folder creation function
function createUserFolder($user_id, $user_data) {
    $base_path = "users/";
    $user_folder = $base_path . $user_id;
    
    // Create main user folder
    if (!is_dir($user_folder)) {
        mkdir($user_folder, 0777, true);
    }
    
    // Create subfolders
    $subfolders = ['profile', 'game_ids', 'tournaments', 'wallet', 'settings'];
    foreach ($subfolders as $folder) {
        if (!is_dir($user_folder . '/' . $folder)) {
            mkdir($user_folder . '/' . $folder, 0777, true);
        }
    }
    
    // Create user info file
    $user_info = [
        'user_id' => $user_id,
        'username' => $user_data['username'],
        'email' => $user_data['email'],
        'phone' => $user_data['phone'] ?? '',
        'game_preference' => $user_data['game_preference'],
        'pubg_id' => '',
        'freefire_id' => '',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    file_put_contents($user_folder . '/profile/info.json', json_encode($user_info, JSON_PRETTY_PRINT));
    
    // Create empty game ID files
    file_put_contents($user_folder . '/game_ids/pubg_id.txt', '');
    file_put_contents($user_folder . '/game_ids/freefire_id.txt', '');
    
    // Create empty tournament history
    file_put_contents($user_folder . '/tournaments/history.json', json_encode([]));
    
    // Create wallet file
    file_put_contents($user_folder . '/wallet/transactions.json', json_encode(['balance' => 0, 'transactions' => []]));
    
    // Create settings file
    file_put_contents($user_folder . '/settings/preferences.json', json_encode(['theme' => 'dark', 'language' => 'en']));
    
    // Update users index
    updateUsersIndex($user_id, $user_data['username']);
    
    return true;
}

// Update users index file
function updateUsersIndex($user_id, $username) {
    $index_file = "users/users_index.json";
    $users_index = [];
    
    if (file_exists($index_file)) {
        $users_index = json_decode(file_get_contents($index_file), true);
    }
    
    $users_index[] = [
        'user_id' => $user_id,
        'username' => $username,
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    file_put_contents($index_file, json_encode($users_index, JSON_PRETTY_PRINT));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Email - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">PlayWithUs</div>
        </div>
    </nav>

    <section class="py-16 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-md mx-auto bg-gray-800 rounded-xl shadow-2xl p-8 border border-gray-700">
                <div class="text-center mb-8">
                    <div class="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-envelope text-2xl text-black"></i>
                    </div>
                    <h1 class="text-3xl font-bold text-yellow-400 mb-2">Verify Your Email</h1>
                    <p class="text-gray-400">We sent a verification code to</p>
                    <p class="text-yellow-400 font-semibold"><?= htmlspecialchars($registration_data['email']) ?></p>
                </div>

                <?php if (isset($errors['database'])): ?>
                    <div class="bg-red-600 text-white p-3 rounded mb-4">
                        <?= $errors['database'] ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-6">
                        <label class="block text-gray-300 mb-3 text-lg font-semibold">
                            <i class="fas fa-shield-alt mr-2 text-yellow-400"></i>Enter OTP
                        </label>
                        <input type="text" name="otp" required 
                               class="w-full px-4 py-4 bg-gray-700 border-2 <?= isset($errors['otp']) ? 'border-red-500' : 'border-gray-600' ?> rounded-xl focus:outline-none focus:border-yellow-500 text-white text-center text-2xl tracking-widest"
                               placeholder="000000"
                               maxlength="6"
                               pattern="[0-9]{6}">
                        <?php if (isset($errors['otp'])): ?>
                            <p class="text-red-400 text-sm mt-2"><?= $errors['otp'] ?></p>
                        <?php else: ?>
                            <p class="text-gray-400 text-sm mt-2">Enter the 6-digit code from your email</p>
                        <?php endif; ?>
                    </div>

                    <button type="submit" 
                            class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl">
                        <i class="fas fa-check-circle mr-3"></i>Verify & Create Account
                    </button>
                </form>

                <div class="mt-6 text-center">
                    <p class="text-gray-400">
                        Didn't receive the code? 
                        <a href="register.php" class="text-yellow-400 hover:underline">Register again</a>
                    </p>
                </div>

                <!-- Debug OTP (Remove in production) -->
                <div class="mt-4 p-3 bg-gray-700 rounded-lg text-center">
                    <p class="text-sm text-gray-400">For testing: OTP is <span class="text-yellow-400 font-bold"><?= $registration_data['otp'] ?></span></p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>