<?php
session_start();
include 'includes/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Debug logging
    error_log("Password Reset Attempt - Token: $token");
    
    // Check if passwords match
    if ($new_password !== $confirm_password) {
        echo json_encode([
            'success' => false,
            'message' => 'Passwords do not match!'
        ]);
        exit();
    }
    
    // Check password length
    if (strlen($new_password) < 6) {
        echo json_encode([
            'success' => false,
            'message' => 'Password must be at least 6 characters long!'
        ]);
        exit();
    }
    
    // Verify reset token from session
    if (isset($_SESSION['reset_token']) && 
        isset($_SESSION['reset_email']) && 
        $_SESSION['reset_token'] === $token) {
        
        $email = $_SESSION['reset_email'];
        
        try {
            // Hash new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            // Update password in database
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->execute([$hashed_password, $email]);
            
            // Check if password was updated
            if ($stmt->rowCount() > 0) {
                // Clear reset session
                unset($_SESSION['reset_token']);
                unset($_SESSION['reset_email']);
                unset($_SESSION['otp']);
                unset($_SESSION['otp_email']);
                unset($_SESSION['otp_expiry']);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Password reset successfully! You can now login with your new password.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update password. User not found.'
                ]);
            }
            
        } catch(PDOException $e) {
            error_log("Database Error: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid or expired reset token. Please request a new OTP.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>