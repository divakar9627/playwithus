
<?php
session_start();
include 'includes/config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Validation
    if (empty($username)) {
        $errors['username'] = 'Username is required';
    }
    
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    }
    
    // If no errors, authenticate user
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['game_preference'] = $user['game_preference'];

                 $_SESSION['user_role'] = $user['user_role'] ?? 'user';
                
                $_SESSION['success'] = 'Login successful! Welcome back ' . $user['username'];
                header('Location: index.php');
                exit();
            } else {
                $errors['login'] = 'Invalid username/email or password';
            }
        } catch(PDOException $e) {
            $errors['database'] = 'Login failed. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Navigation Bar -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">PlayWithUs</div>
            <ul class="flex space-x-6">
                <li><a href="index.php" class="hover:text-yellow-400">Home</a></li>
                <li><a href="create_tournament.php" class="hover:text-yellow-400">Create Tournament</a></li>
                <li><a href="join_tournament.php" class="hover:text-yellow-400">Join Tournament</a></li>
                <li><a href="leaderboard.php" class="hover:text-yellow-400">Leaderboard</a></li>
                <li><a href="login.php" class="hover:text-yellow-400 font-bold">Login</a></li>
                <li><a href="register.php" class="hover:text-yellow-400">Register</a></li>
            </ul>
        </div>
    </nav>

    <!-- Login Section -->
    <section class="py-16 bg-gray-900">
        <div class="container mx-auto px-4">
            <div class="max-w-md mx-auto bg-gray-800 rounded-lg shadow-lg p-8">
                <h2 class="text-3xl font-bold text-center text-yellow-400 mb-8">Login to Your Account</h2>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="bg-green-600 text-white p-3 rounded mb-4">
                        <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($errors['login'])): ?>
                    <div class="bg-red-600 text-white p-3 rounded mb-4">
                        <?= $errors['login'] ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($errors['database'])): ?>
                    <div class="bg-red-600 text-white p-3 rounded mb-4">
                        <?= $errors['database'] ?>
                    </div>
                <?php endif; ?>
                
                <form action="login.php" method="POST">
                    <div class="mb-6">
                        <label for="username" class="block text-gray-300 mb-2">Username or Email</label>
                        <input type="text" id="username" name="username" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['username']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['username'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['username'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6">
                        <label for="password" class="block text-gray-300 mb-2">Password</label>
                        <input type="password" id="password" name="password" required 
                               class="w-full px-4 py-3 bg-gray-700 border <?= isset($errors['password']) ? 'border-red-500' : 'border-gray-600' ?> rounded-lg focus:outline-none focus:border-yellow-500 text-white">
                        <?php if (isset($errors['password'])): ?>
                            <p class="text-red-400 text-sm mt-1"><?= $errors['password'] ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-6 flex items-center justify-between">
                        <div class="flex items-center">
                            <input type="checkbox" id="remember" name="remember" 
                                   class="w-4 h-4 text-yellow-500 bg-gray-700 border-gray-600 rounded focus:ring-yellow-500">
                            <label for="remember" class="ml-2 text-gray-300">Remember me</label>
                        </div>
                        <a href="forgot_password.php" class="text-yellow-400 hover:underline text-sm">Forgot Password?</a>
                    </div>
                    
                    <button type="submit" 
                            class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-4 rounded-lg transition duration-300 mb-4">
                        Login
                    </button>
                    
                    <div class="text-center">
                        <span class="text-gray-400">Or login with</span>
                        <div class="flex justify-center space-x-4 mt-2">
                            <button type="button" class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full">
                                <i class="fab fa-facebook-f"></i>
                            </button>
                            <button type="button" class="bg-blue-400 hover:bg-blue-500 text-white p-2 rounded-full">
                                <i class="fab fa-twitter"></i>
                            </button>
                            <button type="button" class="bg-red-600 hover:bg-red-700 text-white p-2 rounded-full">
                                <i class="fab fa-google"></i>
                            </button>
                        </div>
                    </div>
                </form>
                
                <div class="mt-6 text-center">
                    <p class="text-gray-400">
                        Don't have an account? 
                        <a href="register.php" class="text-yellow-400 hover:underline">Register here</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-16 bg-gray-800">
        <div class="container mx-auto text-center px-4">
            <h2 class="text-4xl font-bold mb-12 text-yellow-400">Why Join PlayWithUs?</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-gray-700 p-6 rounded-lg shadow-lg">
                    <i class="fas fa-trophy text-4xl text-yellow-500 mb-4"></i>
                    <h3 class="text-2xl font-semibold mb-2">Big Prizes</h3>
                    <p>Win up to 50% of the prize pool in our paid tournaments. Real money rewards!</p>
                </div>
                <div class="bg-gray-700 p-6 rounded-lg shadow-lg">
                    <i class="fas fa-gamepad text-4xl text-yellow-500 mb-4"></i>
                    <h3 class="text-2xl font-semibold mb-2">PUBG & Free Fire</h3>
                    <p>Exclusive tournaments for your favorite battle royales. Fair play guaranteed.</p>
                </div>
                <div class="bg-gray-700 p-6 rounded-lg shadow-lg">
                    <i class="fas fa-users text-4xl text-yellow-500 mb-4"></i>
                    <h3 class="text-2xl font-semibold mb-2">Community</h3>
                    <p>Join thousands of gamers. Track your progress on the leaderboard.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 py-8">
        <div class="container mx-auto text-center px-4">
            <p>&copy; 2023 PlayWithUs. All rights reserved.</p>
            <div class="flex justify-center space-x-4 mt-4">
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-facebook"></i></a>
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html> 




