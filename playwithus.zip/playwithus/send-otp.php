<?php
session_start();
include 'includes/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';
    
    // Check if email exists in database
    try {
        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Store OTP in session with expiry
            $_SESSION['otp'] = $otp;
            $_SESSION['otp_email'] = $email;
            $_SESSION['otp_expiry'] = time() + 600; // 10 minutes
            
            // Send OTP via Email
            $email_sent = sendOTPEmail($email, $user['username'], $otp);
            
            if ($email_sent) {
                echo json_encode([
                    'success' => true,
                    'message' => 'OTP sent successfully to your email! Check your inbox.',
                    'debug_otp' => $otp
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to send OTP. Please try again.'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Email not found in our system.'
            ]);
        }
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
}

function sendOTPEmail($to_email, $username, $otp) {
    // Include PHPMailer from smtp folder
    require_once 'smtp/src/PHPMailer.php';
    require_once 'smtp/src/SMTP.php';
    require_once 'smtp/src/Exception.php';
    
    $subject = "Password Reset OTP - PlayWithUs";
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; border-radius: 10px 10px 0 0; color: white; }
            .otp-code { font-size: 32px; font-weight: bold; text-align: center; margin: 30px 0; color: #333; background: #f8f9fa; padding: 15px; border-radius: 8px; letter-spacing: 5px; border: 2px dashed #667eea; }
            .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666; }
            .note { background: #fff3cd; padding: 10px; border-radius: 5px; border-left: 4px solid #ffc107; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🎮 PlayWithUs</h1>
                <p>Password Reset Verification</p>
            </div>
            
            <h2>Hello {$username},</h2>
            <p>You requested to reset your password for your PlayWithUs account. Use the following OTP to verify your identity:</p>
            
            <div class='otp-code'>{$otp}</div>
            
            <div class='note'>
                <strong>Note:</strong> This OTP is valid for <strong>10 minutes</strong>. 
                Do not share this code with anyone.
            </div>
            
            <p>If you didn't request this password reset, please ignore this email and your account will remain secure.</p>
            
            <div class='footer'>
                <p>Happy Gaming! 🎮</p>
                <p><strong>PlayWithUs Team</strong></p>
                <p><small>This is an automated message, please do not reply to this email.</small></p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(); 
        $mail->isSMTP(); 
        $mail->SMTPAuth = true; 
        $mail->SMTPSecure = 'tls'; 
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587; 
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        // $mail->SMTPDebug = 2; // Uncomment for debugging
        
        // 🔹 YOUR GMAIL CREDENTIALS - REPLACE WITH YOUR EMAIL
        $mail->Username = "divakarjha7777@gmail.com"; // अपना Gmail डालें
        $mail->Password = "emhl hyqf bwyy uoeu"; // Your App Password
        $mail->setFrom("divakarjha7777@gmail.com", "PlayWithUs"); // अपना Gmail डालें
        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->addAddress($to_email);
        
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        if($mail->send()){
            return true;
        } else {
            error_log("Email Error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("Mail Exception: " . $e->getMessage());
        return false;
    }
}
?>