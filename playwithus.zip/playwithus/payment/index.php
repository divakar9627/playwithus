<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../users/pages/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = isset($_GET['amount']) ? floatval($_GET['amount']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = floatval($_POST['amount']);
    $payment_method = $_POST['payment_method'];
    
    if ($amount < 10) {
        $error = "Minimum deposit amount is ₹10";
    } else {
        $transaction_id = generateTransactionID();
        
        // Log payment attempt
        logPayment($conn, $user_id, $amount, $payment_method, 'pending', $transaction_id);
        
        // Redirect to respective payment gateway
        switch($payment_method) {
            case 'paytm':
                header("Location: paytm/process_paytm.php?amount=$amount&txn_id=$transaction_id");
                break;
            case 'razorpay':
                header("Location: razorpay/process_razorpay.php?amount=$amount&txn_id=$transaction_id");
                break;
            case 'instamojo':
                header("Location: instamojo/process_instamojo.php?amount=$amount&txn_id=$transaction_id");
                break;
            default:
                $error = "Invalid payment method selected";
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Money - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-gray-800 rounded-xl shadow-2xl p-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-wallet text-3xl text-white"></i>
                </div>
                <h1 class="text-3xl font-bold text-yellow-400 mb-2">Add Money to Wallet</h1>
                <p class="text-gray-400">Secure and instant deposits</p>
            </div>

            <!-- Error Message -->
            <?php if (isset($error)): ?>
                <div class="bg-red-600 text-white p-4 rounded-lg mb-6 text-center">
                    <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Payment Form -->
            <form method="POST" action="">
                <!-- Amount Input -->
                <div class="mb-6">
                    <label class="block text-gray-300 mb-3 text-lg font-semibold">
                        <i class="fas fa-rupee-sign mr-2 text-yellow-400"></i>Amount (₹)
                    </label>
                    <input type="number" name="amount" min="10" max="100000" step="0.01" 
                           value="<?php echo $amount; ?>" required
                           class="w-full px-4 py-4 bg-gray-700 border-2 border-gray-600 rounded-xl focus:outline-none focus:border-yellow-500 text-white text-lg transition duration-300"
                           placeholder="Enter amount (min: ₹10)">
                    <p class="text-gray-400 text-sm mt-2">
                        <i class="fas fa-info-circle mr-1"></i>Minimum: ₹10, Maximum: ₹1,00,000
                    </p>
                </div>

                <!-- Payment Methods -->
                <div class="mb-6">
                    <label class="block text-gray-300 mb-4 text-lg font-semibold">
                        <i class="fas fa-credit-card mr-2 text-yellow-400"></i>Payment Method
                    </label>
                    
                    <div class="space-y-3">
                        <!-- UPI -->
                        <div class="flex items-center p-4 bg-gray-700 rounded-xl hover:bg-gray-600 cursor-pointer transition duration-300">
                            <input type="radio" id="paytm" name="payment_method" value="paytm" class="mr-4 h-5 w-5 text-yellow-500" checked>
                            <label for="paytm" class="flex items-center flex-1 cursor-pointer">
                                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-mobile-alt text-2xl text-blue-600"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-lg">UPI / PayTM</div>
                                    <div class="text-gray-400 text-sm">Google Pay, PhonePe, PayTM</div>
                                </div>
                            </label>
                        </div>

                        <!-- Credit/Debit Card -->
                        <div class="flex items-center p-4 bg-gray-700 rounded-xl hover:bg-gray-600 cursor-pointer transition duration-300">
                            <input type="radio" id="razorpay" name="payment_method" value="razorpay" class="mr-4 h-5 w-5 text-yellow-500">
                            <label for="razorpay" class="flex items-center flex-1 cursor-pointer">
                                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="far fa-credit-card text-2xl text-purple-600"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-lg">Credit/Debit Card</div>
                                    <div class="text-gray-400 text-sm">Visa, MasterCard, RuPay</div>
                                </div>
                            </label>
                        </div>

                        <!-- Net Banking -->
                        <div class="flex items-center p-4 bg-gray-700 rounded-xl hover:bg-gray-600 cursor-pointer transition duration-300">
                            <input type="radio" id="instamojo" name="payment_method" value="instamojo" class="mr-4 h-5 w-5 text-yellow-500">
                            <label for="instamojo" class="flex items-center flex-1 cursor-pointer">
                                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-university text-2xl text-green-600"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-lg">Net Banking</div>
                                    <div class="text-gray-400 text-sm">All Indian Banks</div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Security Info -->
                <div class="bg-yellow-900 border border-yellow-700 rounded-xl p-4 mb-6">
                    <div class="flex items-start">
                        <i class="fas fa-shield-alt text-yellow-400 mt-1 mr-3"></i>
                        <div class="text-yellow-200 text-sm">
                            <strong>Secure Payment:</strong> Your payment information is encrypted and secure. 
                            We don't store your card details.
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" 
                        class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-xl transition duration-300 text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                    <i class="fas fa-lock mr-3"></i>Proceed to Pay ₹<?php echo number_format($amount, 2); ?>
                </button>
            </form>

            <!-- Back Link -->
            <div class="text-center mt-6">
                <a href="../users/pages/my_wallet.php" 
                   class="text-yellow-400 hover:text-yellow-300 text-lg font-semibold transition duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Wallet
                </a>
            </div>
        </div>
    </div>

    <script>
        // Real-time amount update
        document.querySelector('input[name="amount"]').addEventListener('input', function() {
            const button = document.querySelector('button[type="submit"]');
            const amount = this.value ? parseFloat(this.value) : 0;
            button.innerHTML = `<i class="fas fa-lock mr-3"></i>Proceed to Pay ₹${amount.toFixed(2)}`;
        });

        // Enhanced radio button selection
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.querySelectorAll('.bg-gray-600').forEach(el => {
                    el.classList.remove('bg-gray-600');
                    el.classList.add('bg-gray-700');
                });
                this.closest('.bg-gray-700').classList.remove('bg-gray-700');
                this.closest('.bg-gray-700, .bg-gray-600').classList.add('bg-gray-600');
            });
        });
    </script>
</body>
</html>