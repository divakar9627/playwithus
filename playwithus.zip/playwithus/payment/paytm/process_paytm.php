<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../users/pages/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = floatval($_GET['amount']);
$transaction_id = $_GET['txn_id'];

// For testing - directly redirect to success
// In production, you'll integrate with PayTM API
header("Location: ../success.php?txn_id=" . $transaction_id . "&amount=" . $amount);
exit();

/* 
// Production PayTM Integration Code (Uncomment when you have PayTM credentials)

// Include PayTM Kit
require_once('lib/encdec_paytm.php');

// Create PayTM order
$order_id = $transaction_id;
$customer_id = $user_id;
$mobile_no = '9999999999'; // You can get this from user profile
$email = 'user@example.com'; // You can get this from user profile

// PayTM parameters
$paytmParams = array();
$paytmParams["ORDER_ID"] = $order_id;
$paytmParams["CUST_ID"] = $customer_id;
$paytmParams["MOBILE_NO"] = $mobile_no;
$paytmParams["EMAIL"] = $email;
$paytmParams["TXN_AMOUNT"] = $amount;
$paytmParams["CHANNEL_ID"] = PAYTM_CHANNEL_ID;
$paytmParams["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paytmParams["INDUSTRY_TYPE_ID"] = PAYTM_INDUSTRY_TYPE_ID;
$paytmParams["CALLBACK_URL"] = SITE_URL . "/payment/paytm/paytm_response.php";

// Generate checksum
$checksum = getChecksumFromArray($paytmParams, PAYTM_MERCHANT_KEY);
$paytmParams["CHECKSUMHASH"] = $checksum;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Redirecting to PayTM...</title>
</head>
<body>
    <center>
        <h1>Please do not refresh this page...</h1>
        <p>Redirecting to PayTM payment gateway.</p>
    </center>
    
    <form method="post" action="<?php echo PAYTM_TXN_URL; ?>" name="paytm_form">
        <?php
        foreach($paytmParams as $name => $value) {
            echo '<input type="hidden" name="' . $name . '" value="' . $value . '">';
        }
        ?>
    </form>
    
    <script type="text/javascript">
        document.paytm_form.submit();
    </script>
</body>
</html>

<?php
*/
?>