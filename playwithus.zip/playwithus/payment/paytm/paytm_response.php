<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../users/pages/login.php');
    exit();
}

// Include PayTM Kit
// require_once('lib/encdec_paytm.php');

$user_id = $_SESSION['user_id'];

// For testing - simulate successful payment
$transaction_id = 'TXN' . time() . rand(1000, 9999);
$amount = 500; // Default amount for testing

header("Location: ../success.php?txn_id=" . $transaction_id . "&amount=" . $amount);
exit();

/*
// Production PayTM Response Handling
$paytmChecksum = $_POST["CHECKSUMHASH"];
$paytmParams = $_POST;

$isValidChecksum = verifychecksum_e($paytmParams, PAYTM_MERCHANT_KEY, $paytmChecksum);

if($isValidChecksum == "TRUE") {
    if ($_POST["STATUS"] == "TXN_SUCCESS") {
        // Payment successful
        $transaction_id = $_POST["ORDERID"];
        $amount = $_POST["TXNAMOUNT"];
        $payment_id = $_POST["TXNID"];
        
        // Update transaction status
        $update_query = "UPDATE payment_transactions SET status = 'success', payment_id = ? WHERE transaction_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ss", $payment_id, $transaction_id);
        $stmt->execute();
        
        // Update user balance
        updateUserBalance($conn, $user_id, $amount);
        
        header("Location: ../success.php?txn_id=" . $transaction_id . "&amount=" . $amount);
        
    } else {
        // Payment failed
        $transaction_id = $_POST["ORDERID"];
        $error_msg = $_POST["RESPMSG"];
        
        // Update transaction status
        $update_query = "UPDATE payment_transactions SET status = 'failed' WHERE transaction_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("s", $transaction_id);
        $stmt->execute();
        
        header("Location: ../failure.php?txn_id=" . $transaction_id . "&error=" . urlencode($error_msg));
    }
} else {
    // Invalid checksum
    header("Location: ../failure.php?error=Invalid%20Payment%20Response");
}
*/
?>