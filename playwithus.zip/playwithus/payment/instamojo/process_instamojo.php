<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../users/pages/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = floatval($_GET['amount']);
$transaction_id = $_GET['txn_id'];

// For testing - directly redirect to success
header("Location: ../success.php?txn_id=" . $transaction_id . "&amount=" . $amount);
exit();

/*
// Production Instamojo Integration Code

$api = new Instamojo\Instamojo(
    INSTAMOJO_API_KEY,
    INSTAMOJO_AUTH_TOKEN,
    'https://test.instamojo.com/api/1.1/' // Test endpoint
);

try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => "Wallet Deposit",
        "amount" => $amount,
        "send_email" => false,
        "email" => "user@example.com",
        "redirect_url" => SITE_URL . "/payment/instamojo/instamojo_callback.php?txn_id=" . $transaction_id,
        "webhook" => SITE_URL . "/payment/instamojo/instamojo_webhook.php"
    ));
    
    // Store payment request ID
    $payment_request_id = $response['id'];
    
    // Update transaction with payment request ID
    $update_query = "UPDATE payment_transactions SET payment_id = ? WHERE transaction_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ss", $payment_request_id, $transaction_id);
    $stmt->execute();
    
    // Redirect to Instamojo
    header("Location: " . $response['longurl']);
    exit();
    
} catch (Exception $e) {
    header("Location: ../failure.php?txn_id=" . $transaction_id . "&error=" . urlencode($e->getMessage()));
    exit();
}
*/
?>