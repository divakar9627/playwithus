<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../users/pages/login.php');
    exit();
}

$transaction_id = $_GET['txn_id'] ?? '';
$error = $_GET['error'] ?? 'Payment failed';

// Update transaction status to failed
if (!empty($transaction_id)) {
    $update_query = "UPDATE payment_transactions SET status = 'failed' WHERE transaction_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("s", $transaction_id);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-md w-full bg-gray-800 rounded-xl shadow-2xl p-8 text-center">
            <!-- Failure Icon -->
            <div class="w-24 h-24 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-times text-4xl text-white"></i>
            </div>
            
            <h1 class="text-3xl font-bold text-red-400 mb-4">Payment Failed!</h1>
            <p class="text-gray-300 text-lg mb-4"><?php echo htmlspecialchars($error); ?></p>
            
            <?php if (!empty($transaction_id)): ?>
            <div class="bg-gray-700 rounded-xl p-4 mb-6">
                <div class="flex justify-between items-center">
                    <span class="text-gray-400">Transaction ID:</span>
                    <span class="text-yellow-400 font-mono"><?php echo $transaction_id; ?></span>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="space-y-4">
                <a href="index.php" 
                   class="block w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-4 px-6 rounded-xl transition duration-300 text-lg">
                    <i class="fas fa-redo mr-2"></i>Try Again
                </a>
                
                <a href="../users/pages/my_wallet.php" 
                   class="block w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-6 rounded-xl transition duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Wallet
                </a>
            </div>
            
            <div class="mt-6 p-4 bg-yellow-900 border border-yellow-700 rounded-xl">
                <p class="text-yellow-200 text-sm">
                    <i class="fas fa-info-circle mr-2"></i>
                    If money was deducted from your account, it will be refunded within 24 hours.
                </p>
            </div>
        </div>
    </div>
</body>
</html>