<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    die("User not logged in");
}

$user_id = $_SESSION['user_id'];
$amount = floatval($_GET['amount']);
$transaction_id = $_GET['txn_id'];

// For testing - directly show success
// Remove this in production
if ($amount > 0) {
    header("Location: ../success.php?txn_id=" . $transaction_id . "&amount=" . $amount);
    exit();
}

// Razorpay amount should be in paise
$razorpay_amount = $amount * 100;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing Payment - PlayWithUs</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>
    <div style="text-align: center; margin-top: 50px;">
        <h2>Processing Your Payment...</h2>
        <p>Please wait while we redirect you to the payment gateway.</p>
    </div>
    
    <script>
    // For now, we'll redirect to success directly
    // In production, you'll use Razorpay checkout
    setTimeout(function() {
        window.location.href = "../success.php?txn_id=<?php echo $transaction_id; ?>&amount=<?php echo $amount; ?>";
    }, 2000);
    
    /*
    // Production Razorpay Code (Uncomment when you have API keys)
    var options = {
        "key": "<?php echo RAZORPAY_KEY_ID; ?>",
        "amount": "<?php echo $razorpay_amount; ?>",
        "currency": "INR",
        "name": "PlayWithUs",
        "description": "Wallet Deposit",
        "image": "https://yourwebsite.com/logo.png",
        "order_id": "", // This will be generated from your backend
        "handler": function (response){
            window.location.href = "razorpay_success.php?payment_id=" + response.razorpay_payment_id + 
                                  "&order_id=" + response.razorpay_order_id + 
                                  "&signature=" + response.razorpay_signature +
                                  "&txn_id=<?php echo $transaction_id; ?>" +
                                  "&amount=<?php echo $amount; ?>";
        },
        "prefill": {
            "name": "Customer Name",
            "email": "customer@example.com",
            "contact": "9999999999"
        },
        "notes": {
            "address": "Customer Address"
        },
        "theme": {
            "color": "#F37254"
        }
    };
    
    var rzp1 = new Razorpay(options);
    rzp1.open();
    
    rzp1.on('payment.failed', function (response){
        window.location.href = "../failure.php?error=" + response.error.description + "&txn_id=<?php echo $transaction_id; ?>";
    });
    */
    </script>
</body>
</html>