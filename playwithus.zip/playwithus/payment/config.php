<?php
// payment/config.php

// Database configuration
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'playwithus';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// PayTM Configuration (Test Credentials)
define('PAYTM_MERCHANT_MID', 'YOUR_MERCHANT_MID');
define('PAYTM_MERCHANT_KEY', 'YOUR_MERCHANT_KEY');
define('PAYTM_ENVIRONMENT', 'TEST'); // TEST or PROD
define('PAYTM_MERCHANT_WEBSITE', 'WEBSTAGING');
define('PAYTM_CHANNEL_ID', 'WEB');
define('PAYTM_INDUSTRY_TYPE_ID', 'Retail');

// Razorpay Configuration
define('RAZORPAY_KEY_ID', 'rzp_test_YOUR_KEY_ID');
define('RAZORPAY_KEY_SECRET', 'YOUR_KEY_SECRET');

// Base URLs
$base_url = "http://localhost/playwithus";
define('SITE_URL', $base_url);
define('SUCCESS_URL', $base_url . '/payment/success.php');
define('FAILURE_URL', $base_url . '/payment/failure.php');

// Common functions
function generateTransactionID() {
    return 'TXN' . time() . rand(1000, 9999);
}

function logPayment($conn, $user_id, $amount, $payment_method, $status, $transaction_id) {
    $query = "INSERT INTO payment_transactions (user_id, amount, payment_method, status, transaction_id, created_at) 
              VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("idsss", $user_id, $amount, $payment_method, $status, $transaction_id);
    return $stmt->execute();
}

function updateUserBalance($conn, $user_id, $amount) {
    $query = "UPDATE users SET balance = balance + ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("di", $amount, $user_id);
    return $stmt->execute();
}
?>