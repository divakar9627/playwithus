<?php
session_start();
include 'includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Fetch user data to check if game IDs are set
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
} catch(PDOException $e) {
    $errors[] = 'Database error: ' . $e->getMessage();
}

// Sample tournaments data (later you can fetch from database)
$tournaments = [
    [
        'id' => 1,
        'title' => 'PUBG Squad Battle',
        'game' => 'pubg',
        'entry_fee' => 100,
        'prize_pool' => 5000,
        'slots' => 50,
        'max_slots' => 100,
        'date' => '2025-11-15 18:00:00',
        'description' => '4v4 Squad battle. Top 3 teams win prizes.',
        'rules' => 'No hacking. Screen recording required.'
    ],
    [
        'id' => 2,
        'title' => 'Free Fire Duo Clash',
        'game' => 'freefire', 
        'entry_fee' => 50,
        'prize_pool' => 2500,
        'slots' => 30,
        'max_slots' => 50,
        'date' => '2025-11-16 17:00:00',
        'description' => '2v2 Duo match. Winner takes all.',
        'rules' => 'No teaming. Fair play only.'
    ],
    [
        'id' => 3,
        'title' => 'PUBG Solo Championship',
        'game' => 'pubg',
        'entry_fee' => 75,
        'prize_pool' => 3000,
        'slots' => 25,
        'max_slots' => 50,
        'date' => '2025-11-17 19:00:00',
        'description' => 'Solo deathmatch. Only the strongest survive.',
        'rules' => 'Solo play only. No teaming allowed.'
    ]
];

// Handle tournament joining
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['join_tournament'])) {
    $tournament_id = $_POST['tournament_id'];
    
    // Find the selected tournament
    $selected_tournament = null;
    foreach ($tournaments as $tournament) {
        if ($tournament['id'] == $tournament_id) {
            $selected_tournament = $tournament;
            break;
        }
    }
    
    if ($selected_tournament) {
        // Check if user has game ID for this tournament
        $required_game = $selected_tournament['game'];
        $game_id_field = $required_game . '_id';
        
        if (empty($user[$game_id_field])) {
            $errors[] = "You need to set your " . strtoupper($required_game) . " ID in your profile before joining this tournament.";
        } elseif ($selected_tournament['slots'] >= $selected_tournament['max_slots']) {
            $errors[] = "This tournament is already full. Please try another one.";
        } else {
            // Here you would process payment and tournament registration
            // For now, we'll just show success message
            
            // Update tournament slots (in real app, update database)
            $selected_tournament['slots']++;
            
            $success = "Successfully joined " . $selected_tournament['title'] . "! Tournament details will be sent to your email.";
            
            // In real application, you would:
            // 1. Process payment
            // 2. Add user to tournament participants
            // 3. Send confirmation email
            // 4. Update user's tournament history
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Tournament - PlayWithUs</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Navigation Bar -->
    <nav class="bg-gray-800 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="text-2xl font-bold text-yellow-400">PlayWithUs</div>
            <ul class="flex space-x-6 items-center">
                <li><a href="index.php" class="hover:text-yellow-400">Home</a></li>
                <li><a href="create_tournament.php" class="hover:text-yellow-400">Create Tournament</a></li>
                <li><a href="join_tournament.php" class="hover:text-yellow-400 font-bold">Join Tournament</a></li>
                <li><a href="leaderboard.php" class="hover:text-yellow-400">Leaderboard</a></li>
                
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="relative group">
                        <div class="flex items-center space-x-2 cursor-pointer">
                            <div class="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-sm text-black"></i>
                            </div>
                            <span class="text-yellow-400"><?= htmlspecialchars($_SESSION['username']) ?></span>
                            <i class="fas fa-chevron-down text-yellow-400 text-xs"></i>
                        </div>
                        <div class="absolute right-0 mt-2 w-48 bg-gray-700 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                            <a href="users/pages/my_profile.php" class="block px-4 py-3 hover:bg-gray-600 rounded-t-lg">
                                <i class="fas fa-user mr-2"></i>My Profile
                            </a>
                            <a href="users/pages/my_tournaments.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-trophy mr-2"></i>My Tournaments
                            </a>
                            <a href="users/pages/my_wallet.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-wallet mr-2"></i>My Wallet
                            </a>
                            <a href="users/pages/settings.php" class="block px-4 py-3 hover:bg-gray-600">
                                <i class="fas fa-cog mr-2"></i>Settings
                            </a>
                            <div class="border-t border-gray-600">
                                <a href="logout.php" class="block px-4 py-3 hover:bg-gray-600 rounded-b-lg text-red-400">
                                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                                </a>
                            </div>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="hover:text-yellow-400">Login</a></li>
                    <li><a href="register.php" class="hover:text-yellow-400">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <!-- Join Tournament Section -->
    <section class="py-16 bg-gray-900 min-h-screen">
        <div class="container mx-auto px-4">
            <div class="max-w-6xl mx-auto">
                <!-- Header -->
                <div class="text-center mb-12">
                    <h1 class="text-4xl font-bold text-yellow-400 mb-4">Join Tournament</h1>
                    <p class="text-gray-400 text-lg">Compete with the best and win big prizes!</p>
                </div>

                <!-- Success/Error Messages -->
                <?php if (!empty($success)): ?>
                    <div class="bg-green-600 text-white p-4 rounded-lg mb-6 text-center">
                        <?= $success ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="bg-red-600 text-white p-4 rounded-lg mb-6">
                        <?php foreach($errors as $error): ?>
                            <p><?= $error ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- User Game IDs Status -->
                <div class="bg-gray-800 rounded-xl p-6 mb-8">
                    <h3 class="text-xl font-bold text-yellow-400 mb-4">Your Gaming IDs</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                            <div>
                                <i class="fab fa-battle-net text-blue-400 mr-2"></i>
                                <span class="text-gray-300">PUBG ID:</span>
                            </div>
                            <span class="<?= empty($user['pubg_id']) ? 'text-red-400' : 'text-green-400' ?> font-semibold">
                                <?= empty($user['pubg_id']) ? 'Not Set' : htmlspecialchars($user['pubg_id']) ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                            <div>
                                <i class="fas fa-fire text-orange-400 mr-2"></i>
                                <span class="text-gray-300">Free Fire ID:</span>
                            </div>
                            <span class="<?= empty($user['freefire_id']) ? 'text-red-400' : 'text-green-400' ?> font-semibold">
                                <?= empty($user['freefire_id']) ? 'Not Set' : htmlspecialchars($user['freefire_id']) ?>
                            </span>
                        </div>
                    </div>
                    <?php if (empty($user['pubg_id']) || empty($user['freefire_id'])): ?>
                        <p class="text-yellow-400 text-sm mt-3">
                            <i class="fas fa-exclamation-triangle mr-1"></i>
                            Set your gaming IDs in <a href="users/pages/my_profile.php" class="underline">My Profile</a> to join tournaments.
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Tournaments Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach($tournaments as $tournament): ?>
                        <div class="bg-gray-800 rounded-xl shadow-lg overflow-hidden border-2 border-gray-700 hover:border-yellow-500 transition duration-300">
                            <!-- Tournament Image -->
                            <div class="h-48 bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                                <i class="fas fa-trophy text-6xl text-white opacity-80"></i>
                            </div>
                            
                            <!-- Tournament Content -->
                            <div class="p-6">
                                <!-- Game Badge -->
                                <div class="flex justify-between items-start mb-4">
                                    <span class="px-3 py-1 bg-yellow-500 text-black text-sm font-bold rounded-full">
                                        <?= strtoupper($tournament['game']) ?>
                                    </span>
                                    <span class="px-3 py-1 <?= $tournament['slots'] < $tournament['max_slots'] ? 'bg-green-500' : 'bg-red-500' ?> text-white text-sm rounded-full">
                                        <?= $tournament['slots'] ?>/<?= $tournament['max_slots'] ?> Slots
                                    </span>
                                </div>

                                <!-- Tournament Title -->
                                <h3 class="text-xl font-bold text-white mb-2"><?= $tournament['title'] ?></h3>
                                
                                <!-- Tournament Details -->
                                <div class="space-y-2 mb-4">
                                    <div class="flex justify-between">
                                        <span class="text-gray-400">Entry Fee:</span>
                                        <span class="text-yellow-400 font-semibold">₹<?= $tournament['entry_fee'] ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-400">Prize Pool:</span>
                                        <span class="text-green-400 font-semibold">₹<?= $tournament['prize_pool'] ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-400">Date:</span>
                                        <span class="text-gray-300"><?= date('M j, g:i A', strtotime($tournament['date'])) ?></span>
                                    </div>
                                </div>

                                <!-- Description -->
                                <p class="text-gray-400 text-sm mb-4"><?= $tournament['description'] ?></p>

                                <!-- Rules -->
                                <div class="mb-4">
                                    <p class="text-gray-500 text-xs">📋 <?= $tournament['rules'] ?></p>
                                </div>

                                <!-- Join Button -->
                                <form method="POST">
                                    <input type="hidden" name="tournament_id" value="<?= $tournament['id'] ?>">
                                    <button type="submit" name="join_tournament" 
                                            class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-4 rounded-lg transition duration-300 flex items-center justify-center"
                                            <?= (empty($user[$tournament['game'] . '_id']) || $tournament['slots'] >= $tournament['max_slots']) ? 'disabled' : '' ?>>
                                        <?php if (empty($user[$tournament['game'] . '_id'])): ?>
                                            <i class="fas fa-exclamation-triangle mr-2"></i>Set Game ID
                                        <?php elseif ($tournament['slots'] >= $tournament['max_slots']): ?>
                                            <i class="fas fa-times mr-2"></i>Tournament Full
                                        <?php else: ?>
                                            <i class="fas fa-arrow-right mr-2"></i>Join for ₹<?= $tournament['entry_fee'] ?>
                                        <?php endif; ?>
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- No Tournaments Message -->
                <?php if (empty($tournaments)): ?>
                    <div class="text-center py-12">
                        <i class="fas fa-trophy text-6xl text-gray-600 mb-4"></i>
                        <h3 class="text-2xl font-semibold text-gray-400 mb-2">No Tournaments Available</h3>
                        <p class="text-gray-500">Check back later for new tournaments.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 py-8">
        <div class="container mx-auto text-center px-4">
            <p>&copy; 2023 PlayWithUs. All rights reserved.</p>
            <div class="flex justify-center space-x-4 mt-4">
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-facebook"></i></a>
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-yellow-400 hover:text-white"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>